/**
 * src/context/AppContext.jsx
 *
 * Single source of truth for all data that previously lived as
 * useState(INIT_*) in App.jsx.
 *
 * On login:  fetches users, menuItems, ingredients, batches, sales,
 *            storeIssues, wastage, activeShift from the API.
 * On action: updates server first, then local state on success.
 */
import { createContext, useContext, useState, useCallback, useEffect } from "react";
import {
  authApi, usersApi, itemsApi, inventoryApi,
  posApi, shiftsApi, reportsApi,
} from "../api/index.js";
import { classifyExpiry } from "../utils/index.js";
import { ALL_NAV, ALL_PERMISSIONS, DEFAULT_ROLE_PERMISSIONS, CAN_CREATE_ROLES } from "../data/constants.js";

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

export function AppProvider({ children }) {
  // -- Auth --------------------------------------------------------------------
  const [user,        setUser]        = useState(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError,   setAuthError]   = useState(null);

  // -- App data ----------------------------------------------------------------
  const [users,       setUsers]       = useState([]);
  const [menuItems,   setMenuItems]   = useState([]);
  const [ingredients, setIngredients] = useState([]);
  const [batches,     setBatches]     = useState([]);
  const [recipes,     setRecipes]     = useState({});   // { menuId: [{ingredient_id, qty}] }
  const [sales,       setSales]       = useState([]);
  const [storeIssues, setStoreIssues] = useState([]);
  const [wastage,     setWastage]     = useState([]);
  const [shifts,      setShifts]      = useState([]);
  const [activeShift, setActiveShift] = useState(null);

  // -- UI state -----------------------------------------------------------------
  const [holdList,       setHoldList]       = useState([]);
  const [openInvoices,   setOpenInvoices]   = useState([]);
  const [showHoldModal,  setShowHoldModal]  = useState(false);
  const [hhApplied,      setHhApplied]      = useState(false);
  const [hhDiscount,     setHhDiscount]     = useState(20);
  const [sidebarOpen,    setSidebarOpen]    = useState(false);
  const [dataReady,      setDataReady]      = useState(false);

  // -- Load users list on mount for the login screen staff picker --------------
  useEffect(() => {
    const token = localStorage.getItem("access_token");

    if (token) {
      // Try to restore an existing session silently
      authApi.me()
        .then(async (me) => {
          setUser(me);
          await bootstrap(me);
        })
        .catch(() => {
          // Access token stale - try a silent refresh using the cookie
          authApi.refresh()
            .then(async ({ access_token, user: me }) => {
              localStorage.setItem("access_token", access_token);
              setUser(me);
              await bootstrap(me);
            })
            .catch(() => {
              // Both failed - clear everything and show login screen
              localStorage.removeItem("access_token");
              // Fetch users list for the login dropdown (public endpoint not needed
              // - just show empty dropdown, user list loads after first login)
            });
        });
    }
    // No token - show login screen immediately, no API calls
    // Users list is loaded during bootstrap() after a successful login
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const bootstrap = useCallback(async (loggedInUser) => {
    try {
      const [
        usersData,
        itemsData,
        ingredientsData,
        batchesData,
        todaySales,
        issuesData,
        wastageData,
        shiftsData,
        activeShiftData,
        holdsData,
        invoicesData,
      ] = await Promise.all([
        usersApi.list().catch(() => []),
        itemsApi.list().catch(() => []),
        inventoryApi.ingredients().catch(() => []),
        inventoryApi.batches({ limit: 500 }).catch(() => ({ batches: [] })),
        posApi.sales({ limit: 200 }).catch(() => ({ sales: [] })),
        inventoryApi.issues({ limit: 200 }).catch(() => ({ issues: [] })),
        inventoryApi.wastage({ limit: 200 }).catch(() => ({ records: [] })),
        shiftsApi.list({ limit: 50 }).catch(() => ({ shifts: [] })),
        shiftsApi.active().catch(() => null),
        posApi.holds().catch(() => []),
        posApi.invoices().catch(() => []),
      ]);

      setUsers(usersData);
      setMenuItems(itemsData);
      setIngredients(ingredientsData);
      setBatches(batchesData.batches || []);
      setSales(todaySales.sales || []);
      setStoreIssues(issuesData.issues || []);
      setWastage(wastageData.records || []);
      setShifts(shiftsData.shifts || []);
      setActiveShift(activeShiftData);
      setHoldList(holdsData);
      setOpenInvoices(invoicesData);

      // Build recipes map from items data (each item has .recipe array)
      const recipeMap = {};
      for (const item of itemsData) {
        if (item.recipe?.length) {
          recipeMap[item.id] = item.recipe.map(r => ({
            ingredientId: r.ingredient_id,
            qty:          r.qty,
          }));
        }
      }
      setRecipes(recipeMap);

      setDataReady(true);
    } catch (err) {
      console.error("Bootstrap error:", err);
      setDataReady(true); // still render, just with empty data
    }
  }, []);

  // -- Login --------------------------------------------------------------------
  const login = useCallback(async (userId, pin, deviceId) => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      const { access_token, user: loggedInUser } = await authApi.login(userId, pin, deviceId);
      localStorage.setItem("access_token", access_token);
      setUser(loggedInUser);
      await bootstrap(loggedInUser);
      return loggedInUser;
    } catch (err) {
      const msg = err.response?.data?.message || "Invalid credentials";
      setAuthError(msg);
      throw err;
    } finally {
      setAuthLoading(false);
    }
  }, [bootstrap]);

  // -- Logout -------------------------------------------------------------------
  const logout = useCallback(async () => {
    try { await authApi.logout(); } catch (_) {}
    localStorage.removeItem("access_token");
    setUser(null);
    setDataReady(false);
    // Clear all data
    setUsers([]); setMenuItems([]); setIngredients([]);
    setBatches([]); setSales([]); setStoreIssues([]);
    setWastage([]); setShifts([]); setActiveShift(null);
    setHoldList([]); setOpenInvoices([]);
  }, []);

  // -- Derived counts (replaces inline filter in App.jsx) -----------------------
  const expiryAlerts = batches.filter(b => {
    const e = classifyExpiry(b);
    return ["expired", "expiring", "critical"].includes(e.status);
  }).length;

  const lowStockCount = ingredients.filter(ing => {
    const total = batches
      .filter(b => b.ingredient_id === ing.id && b.status === "active")
      .reduce((s, b) => s + Number(b.remaining), 0);
    return total <= Number(ing.reorder_level);
  }).length;

  const allowedNav = ALL_NAV.filter(n => (user?.permissions || []).includes(n.id));

  return (
    <AppContext.Provider value={{
      // Auth
      user, authLoading, authError, login, logout,

      // Data
      users, setUsers,
      menuItems, setMenuItems,
      ingredients, setIngredients,
      batches, setBatches,
      recipes, setRecipes,
      sales, setSales,
      storeIssues, setStoreIssues,
      wastage, setWastage,
      shifts, setShifts,
      activeShift, setActiveShift,

      // UI
      holdList, setHoldList,
      openInvoices, setOpenInvoices,
      showHoldModal, setShowHoldModal,
      hhApplied, setHhApplied,
      hhDiscount, setHhDiscount,
      sidebarOpen, setSidebarOpen,
      dataReady,

      // Derived
      expiryAlerts,
      lowStockCount,
      allowedNav,

      // Constants (still needed by some modules)
      ALL_NAV,
      ALL_PERMISSIONS,
      DEFAULT_ROLE_PERMISSIONS,
      CAN_CREATE_ROLES,
    }}>
      {children}
    </AppContext.Provider>
  );
}
