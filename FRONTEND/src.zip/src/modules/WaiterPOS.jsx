import { useState } from "react";
import { MENU_CATEGORIES, TAX, SVC } from "../data";
import { fmt } from "../utils";
import { T, pillBtn, stepBtn, actionBtn, overlay } from "../posTheme";

const TABLES = ["T01","T02","T03","T04","T05","T06","T07","T08","T09","T10","T11","T12"];

export default function WaiterPOS({ user, menuItems: propMenuItems, holdList, setHoldList, openInvoices, setOpenInvoices }) {
  const ITEMS = propMenuItems || [];

  const [cart,       setCart]       = useState([]);
  const [table,      setTable]      = useState("T01");
  const [category,   setCategory]   = useState("all");
  const [search,     setSearch]     = useState("");
  const [page,       setPage]       = useState(0);
  const [modal,      setModal]      = useState(null);
  const [activeHold, setActiveHold] = useState(null);
  const [noteTarget, setNoteTarget] = useState(null);
  const [noteText,   setNoteText]   = useState("");

  const PER_PAGE = 9;

  const categories = MENU_CATEGORIES.filter(c =>
    c.id === "all" || c.id === "bestseller" ? true : ITEMS.some(m => m.category === c.id)
  );
  const filtered   = ITEMS.filter(item => {
    const matchCat = category === "all" ? true : category === "bestseller" ? item.bestseller : item.category === category;
    return matchCat && item.name.toLowerCase().includes(search.toLowerCase());
  });
  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const pageItems  = filtered.slice(page * PER_PAGE, (page + 1) * PER_PAGE);

  const addToCart  = (item) => setCart(p => { const ex = p.find(c => c.id === item.id); return ex ? p.map(c => c.id === item.id ? {...c, qty: c.qty+1} : c) : [...p, {...item, qty:1, note:""}]; });
  const updateQty  = (id, d) => setCart(p => p.map(c => c.id===id ? {...c, qty: Math.max(0, c.qty+d)} : c).filter(c => c.qty > 0));
  const removeItem = (id)    => setCart(p => p.filter(c => c.id !== id));
  const inCart     = (id)    => cart.find(c => c.id === id)?.qty || 0;

  const subtotal   = cart.reduce((s,c) => s + c.price * c.qty, 0);
  const tax        = subtotal * TAX;
  const service    = subtotal * SVC;
  const grandTotal = subtotal + tax + service;

  const myHolds = holdList.filter(h => h.table === table && h.status === "pending" && h.waiter === user.name);

  const handleSendKitchen = async () => {
    if (!cart.length) return;
    const total = grandTotal;
    const tempId = `HOLD-${Date.now()}`;
    const optimistic = {
      id: tempId, table, waiter: user.name,
      createdDate: new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}),
      items: cart.map(c => ({menuId:c.id, name:c.name, qty:c.qty, price:c.price, emoji:c.emoji, note:c.note||""})),
      subtotal, tax, service, total, status: "pending",
      customerName: `Table ${table}`, createdBy: user.name,
    };
    setHoldList(p => [optimistic, ...p]);
    setCart([]);
    setModal("kitchen_sent");
    setTimeout(() => setModal(null), 2200);
    try {
      const { posApi } = await import("../api/index.js");
      const items = optimistic.items.map(c => ({ menu_item_id: c.menuId, name: c.name, qty: c.qty, price: c.price }));
      const saved = await posApi.createHold({ table_no: table, items, total, notes: `Waiter: ${user.name}` });
      setHoldList(p => p.map(h => h.id === tempId ? { ...h, id: saved.id, hold_ref: saved.hold_ref } : h));
    } catch (err) { console.error("Hold save failed:", err.message); }
  };

  const handleGenerateBill = async (holdEntry) => {
    const invoice = {
      id: `INV-${String(Date.now()).slice(-6)}`, holdId: holdEntry.id,
      table: holdEntry.table, waiter: holdEntry.waiter, items: holdEntry.items,
      subtotal: holdEntry.subtotal, tax: holdEntry.tax, service: holdEntry.service,
      total: holdEntry.total, status: "open",
      createdAt: new Date().toISOString(),
      createdTime: new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}),
    };
    setOpenInvoices(p => [invoice, ...p]);
    setHoldList(p => p.map(h => h.id === holdEntry.id ? {...h, status:"billed", invoiceId: invoice.id} : h));
    setActiveHold(null);
    setModal("bill_sent");
    setTimeout(() => setModal(null), 2500);
    try {
      const { posApi } = await import("../api/index.js");
      await posApi.updateHold(holdEntry.id, { status: "billed" });
    } catch (err) { console.error("Hold update failed:", err.message); }
  };

  return (
    <div style={{flex:1, display:"flex", overflow:"hidden", background:T.bg, fontFamily:T.font, color:T.textPrimary}}>

      {/* LEFT: Cart */}
      <div style={{width:320, display:"flex", flexDirection:"column", background:T.surface, borderRight:`1px solid ${T.border}`}}>
        {/* Header */}
        <div style={{padding:"12px 14px", borderBottom:`1px solid ${T.border}`}}>
          <div style={{display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10}}>
            <div>
              <div style={{fontSize:13, fontWeight:800, color:T.amber, letterSpacing:0.5}}>- WAITER POS</div>
              <div style={{fontSize:10, color:T.textMuted, marginTop:1}}>{user.name}</div>
            </div>
            <div style={{fontSize:11, color:T.textSecondary, background:T.card, padding:"4px 10px", borderRadius:20, border:`1px solid ${T.border}`}}>
              {new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}
            </div>
          </div>
          <div style={{display:"grid", gridTemplateColumns:"repeat(6,1fr)", gap:4}}>
            {TABLES.map(t => {
              const hasPending = holdList.some(h => h.table===t && h.status==="pending");
              const hasBilled  = holdList.some(h => h.table===t && h.status==="billed");
              const isActive   = table === t;
              return (
                <button key={t} onClick={() => setTable(t)} style={{
                  padding:"5px 2px", borderRadius:6, cursor:"pointer", fontSize:10, fontWeight:700, transition:"all .12s",
                  border:`1px solid ${isActive?T.amber:hasBilled?T.green:hasPending?T.amber+"44":T.border}`,
                  background:isActive?T.amber:hasBilled?T.green+"22":hasPending?T.amber+"18":T.card,
                  color:isActive?T.bg:hasBilled?T.green:hasPending?T.amber:T.textSecondary,
                }}>{t}</button>
              );
            })}
          </div>
        </div>

        {/* Kitchen orders for this table */}
        {myHolds.length > 0 && (
          <div style={{padding:"8px 12px", borderBottom:`1px solid ${T.border}`, background:T.amber+"0d"}}>
            <div style={{fontSize:10, fontWeight:700, color:T.amber, marginBottom:6, letterSpacing:0.5}}>KITCHEN ORDERS - TABLE {table}</div>
            {myHolds.map(h => (
              <div key={h.id} style={{display:"flex", justifyContent:"space-between", alignItems:"center", padding:"6px 8px", background:T.card, border:`1px solid ${T.border}`, borderRadius:8, marginBottom:4}}>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontSize:11, fontWeight:600, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{h.items.map(i=>`${i.qty}-${i.name}`).join(", ")}</div>
                  <div style={{fontSize:10, color:T.textMuted, marginTop:1}}>{h.createdDate} - KES {fmt(h.total)}</div>
                </div>
                <button onClick={() => { setActiveHold(h); setModal("confirm_bill"); }} style={{...actionBtn(T.green, true), marginLeft:8, whiteSpace:"nowrap"}}>- Bill</button>
              </div>
            ))}
          </div>
        )}

        {/* Cart label */}
        <div style={{padding:"8px 12px 4px", display:"flex", justifyContent:"space-between", alignItems:"center"}}>
          <div style={{fontSize:10, fontWeight:700, color:T.textMuted, letterSpacing:0.5}}>ORDER - TABLE {table}</div>
          {cart.length > 0 && <button onClick={() => setCart([])} style={{fontSize:10, color:T.red, background:"none", border:"none", cursor:"pointer", fontWeight:700}}>- Clear</button>}
        </div>

        {/* Cart items */}
        <div style={{flex:1, overflowY:"auto", padding:"0 12px"}}>
          {cart.length === 0 ? (
            <div style={{textAlign:"center", padding:"40px 0", color:T.textFaint}}>
              <div style={{fontSize:36}}>-</div>
              <div style={{fontSize:12, marginTop:8}}>Tap items to add to order</div>
            </div>
          ) : cart.map(item => (
            <div key={item.id} style={{display:"flex", alignItems:"center", gap:8, padding:"8px 0", borderBottom:`1px solid ${T.border}`}}>
              <div style={{fontSize:22, width:30, textAlign:"center"}}>{item.emoji}</div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{fontSize:12, fontWeight:600, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{item.name}</div>
                {item.note && <div style={{fontSize:10, color:T.amber, fontStyle:"italic", marginTop:1}}>- {item.note}</div>}
                <div style={{fontSize:11, color:T.textMuted}}>KES {fmt(item.price)} each</div>
              </div>
              <div style={{display:"flex", alignItems:"center", gap:4}}>
                <button onClick={() => updateQty(item.id,-1)} style={stepBtn(T.card)}>-</button>
                <span style={{color:T.amber, fontWeight:800, fontSize:13, minWidth:16, textAlign:"center"}}>{item.qty}</span>
                <button onClick={() => updateQty(item.id,1)} style={stepBtn(T.amber)}>+</button>
              </div>
              <div style={{textAlign:"right", minWidth:50}}>
                <div style={{fontSize:12, fontWeight:700}}>KES {fmt(item.price*item.qty)}</div>
                <button onClick={() => { setNoteTarget(item.id); setNoteText(item.note||""); }} style={{fontSize:9, color:T.textMuted, background:"none", border:"none", cursor:"pointer", padding:0}}>- note</button>
              </div>
              <button onClick={() => removeItem(item.id)} style={{background:"none", border:"none", cursor:"pointer", color:T.textFaint, fontSize:13, padding:"0 2px"}}>-</button>
            </div>
          ))}
        </div>

        {/* Totals + Send */}
        {cart.length > 0 && (
          <div style={{borderTop:`1px solid ${T.border}`, padding:"12px 14px", background:T.card}}>
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8, marginBottom:12}}>
              {[["Subtotal", subtotal],["Tax 16%", tax],["Total", grandTotal]].map(([l,v]) => (
                <div key={l} style={{textAlign:"center"}}>
                  <div style={{fontSize:9, color:T.textMuted, marginBottom:2}}>{l}</div>
                  <div style={{fontSize:l==="Total"?14:11, fontWeight:l==="Total"?800:600, color:l==="Total"?T.amber:T.textPrimary}}>KES {fmt(v)}</div>
                </div>
              ))}
            </div>
            <button onClick={handleSendKitchen} style={{width:"100%", padding:"12px", borderRadius:10, border:"none", cursor:"pointer", background:`linear-gradient(135deg,${T.amber},#d97706)`, color:T.bg, fontWeight:800, fontSize:14, letterSpacing:0.5, fontFamily:T.font}}>
              - SEND TO KITCHEN
            </button>
          </div>
        )}
      </div>

      {/* RIGHT: Menu Grid */}
      <div style={{flex:1, display:"flex", flexDirection:"column", overflow:"hidden", background:T.bg}}>
        {/* Search + Category tabs */}
        <div style={{background:T.surface, borderBottom:`1px solid ${T.border}`, padding:"10px 14px 0", flexShrink:0}}>
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} placeholder="-  Search menu-"
            style={{width:"100%", padding:"8px 14px", border:`1px solid ${T.border}`, borderRadius:20, fontSize:13, outline:"none", marginBottom:10, boxSizing:"border-box", background:T.card, color:T.textPrimary}}/>
          <div style={{display:"flex", gap:0, overflowX:"auto"}}>
            {categories.map(cat => (
              <button key={cat.id} onClick={() => { setCategory(cat.id); setPage(0); }} style={{
                padding:"8px 14px", border:"none", cursor:"pointer", fontWeight:700, whiteSpace:"nowrap", fontSize:12, background:"transparent",
                color:category===cat.id?T.textPrimary:T.textMuted,
                borderBottom:`3px solid ${category===cat.id?T.amber:"transparent"}`,
                transition:"all .12s", fontFamily:T.font,
              }}>{cat.emoji} {cat.label}</button>
            ))}
          </div>
        </div>

        {/* Menu items */}
        <div style={{flex:1, overflowY:"auto", padding:14}}>
          <div style={{display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10}}>
            {pageItems.map(item => {
              const qty = inCart(item.id);
              return (
                <div key={item.id} onClick={() => addToCart(item)} style={{
                  borderRadius:12, overflow:"hidden", cursor:"pointer",
                  border:`2px solid ${qty>0?T.amber:T.border}`, background:T.card, transition:"all .15s",
                  boxShadow:qty>0?`0 0 0 1px ${T.amber}44, 0 4px 16px rgba(245,158,11,0.15)`:"none",
                }}>
                  <div style={{height:88, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:4, position:"relative",
                    background:qty>0?`linear-gradient(135deg,${T.amberDim},#b45309)`:"linear-gradient(135deg,#1e293b,#334155)"}}>
                    <div style={{fontSize:32}}>{item.emoji}</div>
                    {qty > 0 && <div style={{position:"absolute", top:6, right:6, background:T.amber, color:T.bg, borderRadius:"50%", width:22, height:22, fontSize:11, fontWeight:800, display:"flex", alignItems:"center", justifyContent:"center"}}>{qty}</div>}
                    {item.bestseller && <div style={{position:"absolute", top:6, left:6, background:T.red, color:"#fff", fontSize:8, fontWeight:700, padding:"1px 5px", borderRadius:8}}>- HOT</div>}
                    {item.onSale && <div style={{position:"absolute", bottom:4, left:6, background:"#7c3aed", color:"#fff", fontSize:8, fontWeight:700, padding:"1px 5px", borderRadius:8}}>SALE</div>}
                  </div>
                  <div style={{padding:"8px 10px"}}>
                    <div style={{fontSize:12, fontWeight:700, color:T.textPrimary, marginBottom:2, lineHeight:1.2}}>{item.name}</div>
                    <div style={{fontSize:13, fontWeight:800, color:qty>0?T.amber:T.textSecondary}}>KES {fmt(item.price)}</div>
                  </div>
                </div>
              );
            })}
          </div>
          {totalPages > 1 && (
            <div style={{display:"flex", justifyContent:"center", gap:8, marginTop:14}}>
              <button onClick={() => setPage(p=>Math.max(0,p-1))} disabled={page===0} style={{...pillBtn(false), opacity:page===0?0.4:1}}>- Prev</button>
              <span style={{fontSize:12, color:T.textMuted, padding:"6px 10px"}}>{page+1} / {totalPages}</span>
              <button onClick={() => setPage(p=>Math.min(totalPages-1,p+1))} disabled={page>=totalPages-1} style={{...pillBtn(false), opacity:page>=totalPages-1?0.4:1}}>Next -</button>
            </div>
          )}
        </div>
      </div>

      {/* Note Modal */}
      {noteTarget && (
        <div style={overlay}>
          <div style={{background:T.surface, border:`1px solid ${T.border}`, borderRadius:14, padding:24, width:300}}>
            <div style={{fontWeight:700, fontSize:14, marginBottom:10}}>- Item Note</div>
            <textarea value={noteText} onChange={e=>setNoteText(e.target.value)} placeholder="e.g. no onions, extra sauce-"
              style={{width:"100%", height:80, borderRadius:10, border:`1px solid ${T.border}`, padding:10, fontSize:13, resize:"none", outline:"none", boxSizing:"border-box", background:T.card, color:T.textPrimary}}/>
            <div style={{display:"flex", gap:8, marginTop:12}}>
              <button onClick={() => setNoteTarget(null)} style={actionBtn(T.textFaint)}>Cancel</button>
              <button onClick={() => { setCart(p=>p.map(c=>c.id===noteTarget?{...c,note:noteText}:c)); setNoteTarget(null); }} style={{...actionBtn(T.amber), flex:1, color:T.bg}}>Save Note</button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Bill Modal */}
      {modal === "confirm_bill" && activeHold && (
        <div style={overlay}>
          <div style={{background:T.surface, border:`1px solid ${T.border}`, borderRadius:16, width:360, overflow:"hidden"}}>
            <div style={{background:`linear-gradient(135deg,${T.bg},${T.card})`, padding:"18px 22px", borderBottom:`1px solid ${T.border}`}}>
              <div style={{fontSize:16, fontWeight:800, color:T.amber}}>Generate Customer Bill</div>
              <div style={{fontSize:11, color:T.textMuted, marginTop:2}}>Table {activeHold.table} - {activeHold.createdDate}</div>
            </div>
            <div style={{padding:20}}>
              <div style={{background:T.card, border:`1px solid ${T.border}`, borderRadius:10, padding:"12px 14px", marginBottom:14}}>
                {activeHold.items.map(i => (
                  <div key={i.menuId} style={{display:"flex", justifyContent:"space-between", fontSize:12, padding:"3px 0", borderBottom:`1px solid ${T.border}`, color:T.textSecondary}}>
                    <span>{i.emoji} {i.qty}- {i.name}</span>
                    <span style={{fontWeight:600, color:T.textPrimary}}>KES {fmt(i.price*i.qty)}</span>
                  </div>
                ))}
                <div style={{display:"flex", justifyContent:"space-between", fontSize:14, fontWeight:800, marginTop:10}}>
                  <span>Total</span><span style={{color:T.amber}}>KES {fmt(activeHold.total)}</span>
                </div>
              </div>
              <div style={{fontSize:12, color:T.textSecondary, background:T.amber+"11", border:`1px solid ${T.amber}33`, borderRadius:8, padding:"8px 12px", marginBottom:14}}>
                - Creates an open invoice at the cashier's POS.
              </div>
              <div style={{display:"flex", gap:10}}>
                <button onClick={() => { setModal(null); setActiveHold(null); }} style={actionBtn(T.card)}>Cancel</button>
                <button onClick={() => handleGenerateBill(activeHold)} style={{...actionBtn(T.green), flex:1}}>- Send to Cashier</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {(modal === "kitchen_sent" || modal === "bill_sent") && (
        <div style={{position:"fixed", bottom:32, left:"50%", transform:"translateX(-50%)", background:modal==="bill_sent"?T.green:T.amber, color:modal==="bill_sent"?"#fff":T.bg, borderRadius:12, padding:"13px 26px", fontSize:14, fontWeight:700, boxShadow:"0 8px 32px rgba(0,0,0,.4)", zIndex:999, display:"flex", alignItems:"center", gap:8}}>
          {modal==="kitchen_sent" ? "- Order sent to kitchen!" : "- Invoice sent to cashier!"}
        </div>
      )}
    </div>
  );
}
