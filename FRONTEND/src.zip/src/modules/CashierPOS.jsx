import { useState } from "react";
import { TAX, SVC, d } from "../data";
import { fmt, deductStock } from "../utils";
import { T, pillBtn, actionBtn, overlay, modal as modalStyle } from "../posTheme";
import { ReceiptModal } from "../components/POSShared";

// --- Main CashierPOS ----------------------------------------------------------
export default function CashierPOS({ 
  user, 
  sales, 
  setSales, 
  batches, 
  setBatches, 
  openInvoices, 
  setOpenInvoices, 
  recipes, 
  ingredients, 
  holdList 
}) {

  const [selectedInv, setSelectedInv] = useState(null);
  const [payMethod,   setPayMethod]   = useState("cash");
  const [mpesaPhone,  setMpesaPhone]  = useState("");
  const [tendered,    setTendered]    = useState("");
  const [step,        setStep]        = useState("list");
  const [processing,  setProcessing]  = useState(false);
  const [filter,      setFilter]      = useState("open");
  const [receipt,     setReceipt]     = useState(null);

  const openList     = openInvoices.filter(inv => filter === "all" ? true : inv.status === "open");
  const tenderedNum  = parseFloat(tendered) || 0;
  const billTotal    = selectedInv ? (selectedInv.finalTotal ?? selectedInv.total) : 0;
  const changeDue    = tenderedNum - billTotal;

  const quickAmounts = selectedInv ? [
    Math.ceil(billTotal/100)*100,
    Math.ceil(billTotal/500)*500,
    Math.ceil(billTotal/1000)*1000,
  ].filter((v,i,a) => a.indexOf(v)===i && v>=billTotal).slice(0,3) : [];


  const handleConfirmPayment = async () => {
    setProcessing(true);
    try {
      const total    = Math.round(selectedInv.finalTotal ?? selectedInv.total);
      const tendered = parseFloat(tenderedNum) || total;
      const items    = (selectedInv.items || []).map(i => ({
        menu_item_id: i.menuId || i.menu_item_id,
        qty:          i.qty,
        unit_price:   i.price || i.unit_price || 0,
        name:         i.name || "",
      }));

      // Post sale to API (FEFO deduction happens server-side)
      const { posApi } = await import("../api/index.js");
      const saved = await posApi.createSale({
        items,
        customer:    selectedInv.table ? `Table ${selectedInv.table}` : "Walk-in",
        table_no:    selectedInv.table || null,
        payment:     payMethod,
        payment_ref: mpesaPhone || null,
        tendered,
        total,
        waiter_id:   selectedInv.waiter_id || null,
      });

      // Update local state
      const localSale = {
        id: saved.id, date: d(0),
        time: new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),
        customer: saved.customer, table: saved.table_no,
        items, total, payment: payMethod,
        cashier: user?.name, waiter: selectedInv.waiter,
      };
      setSales(p => [...p, localSale]);

      // Optimistic stock deduction for UI responsiveness
      deductStock(selectedInv.items, setBatches, recipes);

      // Mark invoice as paid
      setOpenInvoices(p => p.map(inv => inv.id === selectedInv.id
        ? { ...inv, status: "paid", paidAt: new Date().toISOString(), paidBy: user.name, payMethod, saleId: saved.id }
        : inv
      ));

      // Open receipt PDF in new tab
      if (saved.id) {
        const receiptUrl = posApi.receiptUrl(saved.id);
        window.open(receiptUrl, "_blank");
      }

      setProcessing(false);
      setStep("done");
    } catch (err) {
      console.error("Payment failed:", err.message);
      // Fall back to local-only if API is down
      const total = Math.round(selectedInv.finalTotal ?? selectedInv.total);
      setSales(p => [...p, { id: `LOCAL-${Date.now()}`, date: d(0), total, payment: payMethod, items: selectedInv.items || [] }]);
      deductStock(selectedInv.items, setBatches, recipes);
      setOpenInvoices(p => p.map(inv => inv.id === selectedInv.id ? { ...inv, status: "paid" } : inv));
      setProcessing(false);
      setStep("done");
    }
  };

  const handleReset = () => { 
    setSelectedInv(null); 
    setStep("list"); 
    setPayMethod("cash"); 
    setMpesaPhone(""); 
    setTendered(""); 
  };

  return (
    <div style={{
      flex: 1, 
      display: "flex", 
      overflow: "hidden", 
      background: T.bg, 
      fontFamily: T.font, 
      color: T.textPrimary
    }}>

      {/* LEFT: Invoice List */}
      <div style={{
        width: 400, 
        display: "flex", 
        flexDirection: "column", 
        background: T.surface, 
        borderRight: `1px solid ${T.border}`
      }}>
        <div style={{
          padding: "18px 20px 14px", 
          borderBottom: `1px solid ${T.border}`
        }}>
          <div style={{
            display: "flex", 
            alignItems: "center", 
            justifyContent: "space-between", 
            marginBottom: 14
          }}>
            <div>
              <div style={{
                fontSize: 12, 
                fontWeight: 700, 
                color: T.amber, 
                letterSpacing: 1,
                textTransform: "uppercase",
              }}>
                Cashier Terminal
              </div>
              <div style={{
                fontSize: 10, 
                color: T.textMuted, 
                marginTop: 2
              }}>
                {user.name}
              </div>
            </div>
            <div style={{
              fontSize: 11, 
              fontWeight: 700, 
              background: `${T.amber}20`, 
              color: T.amber, 
              padding: "4px 12px", 
              borderRadius: 4,
              letterSpacing: 0.5,
            }}>
              {openInvoices.filter(i=>i.status==="open").length} OPEN
            </div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            {[
              ["open","Open Invoices"],
              ["all","All Today"]
            ].map(([k,l]) => (
              <button 
                key={k} 
                onClick={()=>setFilter(k)} 
                style={{
                  ...pillBtn(filter===k), 
                  flex: 1,
                  fontSize: 11,
                  letterSpacing: 0.3,
                }}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px" }}>
          {openList.length === 0 && (
            <div style={{
              textAlign: "center", 
              padding: "60px 0", 
              color: T.textFaint
            }}>
              <div style={{
                fontSize: 48, 
                fontWeight: 300,
                marginBottom: 12,
                color: T.textMuted,
              }}>
                -
              </div>
              <div style={{ fontSize: 13, marginTop: 8, fontWeight: 500 }}>
                No open invoices
              </div>
              <div style={{ fontSize: 11, marginTop: 4 }}>
                Awaiting orders from service staff
              </div>
            </div>
          )}
          {openList.map(inv => {
            const isPaid     = inv.status === "paid";
            const isVoided   = inv.status === "voided";
            const isSelected = selectedInv?.id === inv.id;
            const dispTotal  = inv.finalTotal ?? inv.total;
            return (
              <div key={inv.id}
                onClick={() => { 
                  if (!isPaid && !isVoided) { 
                    setSelectedInv(inv); 
                    setStep("pay"); 
                    setTendered(""); 
                  } 
                }}
                style={{
                  borderRadius: 6, 
                  padding: "14px 16px", 
                  marginBottom: 10, 
                  cursor: isPaid||isVoided ? "default" : "pointer",
                  background: isSelected ? `${T.amber}12` : T.card,
                  border: `1px solid ${isSelected ? T.amber : isPaid ? `${T.success}50` : isVoided ? `${T.error}50` : T.border}`,
                  transition: "all 0.15s ease", 
                  opacity: isPaid||isVoided ? 0.7 : 1,
                }}>
                <div style={{
                  display: "flex", 
                  justifyContent: "space-between", 
                  alignItems: "flex-start", 
                  marginBottom: 6
                }}>
                  <div>
                    <div style={{
                      fontSize: 12, 
                      fontWeight: 600, 
                      color: isPaid ? T.success : isVoided ? T.error : T.amber,
                      letterSpacing: 0.3,
                    }}>
                      #{inv.id}
                    </div>
                    <div style={{
                      fontSize: 11, 
                      color: T.textMuted, 
                      marginTop: 2
                    }}>
                      Table {inv.table} - {inv.waiter}
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{
                      fontSize: 15, 
                      fontWeight: 700,
                      color: T.textPrimary,
                    }}>
                      KES {fmt(dispTotal)}
                    </div>
                    {inv.discount && (
                      <div style={{
                        fontSize: 9, 
                        color: T.amber,
                        marginTop: 2,
                      }}>
                        -KES {fmt(inv.discount)}
                      </div>
                    )}
                    <div style={{
                      fontSize: 9, 
                      fontWeight: 600, 
                      padding: "2px 8px", 
                      borderRadius: 4, 
                      marginTop: 4, 
                      display: "inline-block",
                      background: isPaid ? `${T.success}20` : isVoided ? `${T.error}20` : `${T.amber}20`,
                      color: isPaid ? T.success : isVoided ? T.error : T.amber,
                      letterSpacing: 0.3,
                    }}>
                      {isPaid ? "PAID" : isVoided ? "VOID" : "OPEN"}
                    </div>
                  </div>
                </div>
                <div style={{
                  fontSize: 10, 
                  color: T.textFaint, 
                  overflow: "hidden", 
                  textOverflow: "ellipsis", 
                  whiteSpace: "nowrap"
                }}>
                  {inv.items.map(i=>`${i.qty}- ${i.name}`).join(" - ")}
                </div>
                {isPaid && (
                  <div style={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    alignItems: "center", 
                    marginTop: 8,
                    paddingTop: 8,
                    borderTop: `1px solid ${T.border}`,
                  }}>
                    <div style={{
                      fontSize: 9, 
                      color: T.success,
                      letterSpacing: 0.3,
                    }}>
                      Paid via {inv.payMethod?.toUpperCase()} - {inv.paidBy}
                    </div>
                    <button 
                      onClick={e => { e.stopPropagation(); setReceipt(inv); }} 
                      style={{
                        ...actionBtn(T.success, true),
                        fontSize: 10,
                        padding: "4px 12px",
                      }}
                    >
                      Receipt
                    </button>
                  </div>
                )}
                {isVoided && (
                  <div style={{
                    fontSize: 9, 
                    color: T.error, 
                    marginTop: 4
                  }}>
                    Voided by {inv.voidedBy}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* RIGHT: Payment Panel */}
      <div style={{
        flex: 1, 
        display: "flex", 
        flexDirection: "column", 
        overflow: "hidden", 
        position: "relative"
      }}>

        {/* Empty state */}
        {step === "list" && (
          <div style={{
            flex: 1, 
            display: "flex", 
            flexDirection: "column", 
            alignItems: "center", 
            justifyContent: "center", 
            color: T.textMuted
          }}>
            <div style={{
              fontSize: 64, 
              fontWeight: 300,
              marginBottom: 16,
              color: T.textFaint,
            }}>
              -
            </div>
            <div style={{
              fontSize: 16, 
              fontWeight: 500, 
              color: T.textSecondary
            }}>
              Select an open invoice
            </div>
            <div style={{
              fontSize: 12, 
              marginTop: 6,
              color: T.textMuted,
            }}>
              Choose an invoice from the list to process payment
            </div>
          </div>
        )}

        {/* Payment form */}
        {(step === "pay" || step === "confirm") && selectedInv && (
          <div style={{ flex: 1, overflowY: "auto", padding: 28 }}>
            <div style={{
              background: T.surface, 
              borderRadius: 8, 
              padding: "20px 24px", 
              marginBottom: 20, 
              border: `1px solid ${T.border}`
            }}>

              {/* Invoice header */}
              <div style={{
                display: "flex", 
                justifyContent: "space-between", 
                alignItems: "center", 
                marginBottom: 18
              }}>
                <div>
                  <div style={{
                    fontSize: 18, 
                    fontWeight: 600,
                    color: T.textPrimary,
                  }}>
                    Invoice #{selectedInv.id}
                  </div>
                  <div style={{
                    fontSize: 11, 
                    color: T.textMuted, 
                    marginTop: 4
                  }}>
                    Table {selectedInv.table} - Waiter: {selectedInv.waiter}
                  </div>
                  {selectedInv.discount && (
                    <div style={{
                      fontSize: 11, 
                      color: T.amber, 
                      marginTop: 4
                    }}>
                      Discount applied: -KES {fmt(selectedInv.discount)}
                    </div>
                  )}
                </div>
                <button 
                  onClick={handleReset} 
                  style={{
                    ...actionBtn(T.card), 
                    fontSize: 11,
                    padding: "6px 16px",
                  }}
                >
                  Back
                </button>
              </div>

              {/* Items */}
              <div style={{
                background: T.card, 
                border: `1px solid ${T.border}`, 
                borderRadius: 6, 
                padding: "12px 16px", 
                marginBottom: 18
              }}>
                <div style={{
                  fontSize: 10, 
                  fontWeight: 600, 
                  color: T.textMuted, 
                  letterSpacing: 0.5, 
                  marginBottom: 10,
                  textTransform: "uppercase",
                }}>
                  Order Items
                </div>
                {selectedInv.items.map(item => (
                  <div key={item.menuId} style={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    alignItems: "center", 
                    padding: "6px 0", 
                    borderBottom: `1px solid ${T.border}`
                  }}>
                    <span style={{
                      fontSize: 12, 
                      color: T.textSecondary
                    }}>
                      {item.qty}- {item.name}
                    </span>
                    <span style={{
                      fontSize: 12, 
                      fontWeight: 600,
                      color: T.textPrimary,
                    }}>
                      KES {fmt(item.price*item.qty)}
                    </span>
                  </div>
                ))}
                <div style={{
                  display: "grid", 
                  gridTemplateColumns: "1fr 1fr 1fr", 
                  gap: 10, 
                  marginTop: 12
                }}>
                  {[
                    ["Subtotal", selectedInv.subtotal],
                    ["Tax 16%", selectedInv.tax],
                    ["Service 5%", selectedInv.service]
                  ].map(([l,v]) => (
                    <div key={l} style={{
                      textAlign: "center", 
                      background: T.bg, 
                      borderRadius: 6, 
                      padding: "8px 6px"
                    }}>
                      <div style={{
                        fontSize: 9, 
                        color: T.textMuted, 
                        fontWeight: 600,
                        letterSpacing: 0.3,
                      }}>
                        {l}
                      </div>
                      <div style={{
                        fontSize: 11, 
                        fontWeight: 600, 
                        marginTop: 3,
                        color: T.textPrimary,
                      }}>
                        KES {fmt(v)}
                      </div>
                    </div>
                  ))}
                </div>
                {selectedInv.discount && (
                  <div style={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    fontSize: 11, 
                    color: T.amber, 
                    marginTop: 10, 
                    padding: "6px 0"
                  }}>
                    <span>Discount</span>
                    <span>- KES {fmt(selectedInv.discount)}</span>
                  </div>
                )}
                <div style={{
                  display: "flex", 
                  justifyContent: "space-between", 
                  alignItems: "center", 
                  marginTop: 12, 
                  padding: "12px 14px", 
                  background: T.bg, 
                  borderRadius: 6
                }}>
                  <span style={{
                    fontSize: 13, 
                    fontWeight: 600, 
                    color: T.amber,
                    letterSpacing: 0.5,
                  }}>
                    GRAND TOTAL
                  </span>
                  <span style={{
                    fontSize: 22, 
                    fontWeight: 700, 
                    color: T.amber,
                    fontFamily: "'Inter', monospace",
                  }}>
                    KES {fmt(billTotal)}
                  </span>
                </div>
              </div>

              {/* Payment method */}
              <div style={{ marginBottom: 18 }}>
                <div style={{
                  fontSize: 10, 
                  fontWeight: 600, 
                  color: T.textMuted, 
                  letterSpacing: 0.5, 
                  marginBottom: 12,
                  textTransform: "uppercase",
                }}>
                  Select Payment Method
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
                  {[
                    {k:"cash",  label:"Cash",   color: T.success},
                    {k:"mpesa", label:"M-Pesa", color: T.mpesa},
                    {k:"card",  label:"Card",   color: T.blue},
                  ].map(({k,label,color}) => (
                    <button 
                      key={k} 
                      onClick={() => { 
                        setPayMethod(k); 
                        setTendered(""); 
                        setMpesaPhone(""); 
                      }} 
                      style={{
                        padding: "14px 8px", 
                        borderRadius: 6,
                        border: `2px solid ${payMethod === k ? color : T.border}`,
                        background: payMethod === k ? `${color}12` : T.card,
                        cursor: "pointer", 
                        display: "flex", 
                        flexDirection: "column", 
                        alignItems: "center", 
                        gap: 6,
                        fontFamily: T.font, 
                        transition: "all 0.15s ease",
                      }}
                    >
                      <div style={{
                        fontSize: 20, 
                        fontWeight: payMethod === k ? 700 : 500,
                        color: payMethod === k ? color : T.textMuted,
                      }}>
                        {label}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* M-Pesa panel */}
              {payMethod === "mpesa" && (
                <div style={{
                  background: `${T.mpesa}08`, 
                  border: `1px solid ${T.mpesa}40`, 
                  borderRadius: 6, 
                  padding: 18, 
                  marginBottom: 18
                }}>
                  <div style={{
                    fontSize: 11, 
                    fontWeight: 600, 
                    color: T.mpesa, 
                    marginBottom: 12,
                    letterSpacing: 0.3,
                  }}>
                    M-PESA PAYMENT
                  </div>
                  <div style={{ display: "flex", gap: 10 }}>
                    <input 
                      value={mpesaPhone} 
                      onChange={e => setMpesaPhone(e.target.value.replace(/\D/g,""))} 
                      placeholder="07XX XXX XXX" 
                      maxLength={12}
                      style={{
                        flex: 1, 
                        padding: "10px 14px", 
                        border: `1px solid ${T.mpesa}60`, 
                        borderRadius: 6, 
                        fontSize: 13, 
                        outline: "none", 
                        fontWeight: 500, 
                        letterSpacing: 0.5, 
                        background: T.card, 
                        color: T.textPrimary,
                        fontFamily: T.font,
                      }}
                    />
                    <button 
                      onClick={() => { 
                        if(mpesaPhone.length >= 9) setStep("confirm"); 
                      }}
                      disabled={mpesaPhone.length < 9}
                      style={{
                        ...actionBtn(mpesaPhone.length>=9 ? T.mpesa : T.textFaint), 
                        padding: "10px 20px",
                        fontSize: 12,
                        fontWeight: 600,
                      }}
                    >
                      Process
                    </button>
                  </div>
                  <div style={{
                    fontSize: 9, 
                    color: T.mpesa, 
                    marginTop: 8,
                    letterSpacing: 0.3,
                  }}>
                    Customer will receive a payment prompt
                  </div>
                  <div style={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    marginTop: 12, 
                    padding: "8px 12px", 
                    background: T.card, 
                    borderRadius: 6
                  }}>
                    <span style={{ fontSize: 11, color: T.textSecondary }}>Amount:</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: T.mpesa }}>
                      KES {fmt(billTotal)}
                    </span>
                  </div>
                </div>
              )}

              {/* Cash panel */}
              {payMethod === "cash" && (
                <div style={{
                  background: `${T.success}08`, 
                  border: `1px solid ${T.success}40`, 
                  borderRadius: 6, 
                  padding: 18, 
                  marginBottom: 18
                }}>
                  <div style={{
                    fontSize: 11, 
                    fontWeight: 600, 
                    color: T.success, 
                    marginBottom: 12,
                    letterSpacing: 0.3,
                  }}>
                    CASH COLLECTION
                  </div>
                  <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                    {[...quickAmounts, "Exact"].map(v => {
                      const val = v === "Exact" ? String(Math.round(billTotal)) : String(v);
                      return (
                        <button 
                          key={v} 
                          onClick={() => setTendered(val)}
                          style={{
                            flex: 1, 
                            padding: "8px 4px", 
                            borderRadius: 6, 
                            border: `1px solid ${tendered === val ? T.success : T.border}`,
                            background: tendered === val ? T.success : T.card,
                            color: tendered === val ? "#FFFFFF" : T.textSecondary,
                            fontSize: 11, 
                            fontWeight: 600, 
                            cursor: "pointer", 
                            fontFamily: T.font,
                            transition: "all 0.15s ease",
                          }}
                        >
                          {v === "Exact" ? "Exact" : `KES ${Number(v).toLocaleString()}`}
                        </button>
                      );
                    })}
                  </div>
                  <div style={{
                    display: "flex", 
                    alignItems: "center", 
                    gap: 10, 
                    marginBottom: 12
                  }}>
                    <label style={{
                      fontSize: 11, 
                      color: T.success, 
                      fontWeight: 600, 
                      whiteSpace: "nowrap",
                      letterSpacing: 0.3,
                    }}>
                      Tendered
                    </label>
                    <input 
                      type="number" 
                      min={0} 
                      value={tendered} 
                      onChange={e => setTendered(e.target.value)} 
                      placeholder={`- ${Math.round(billTotal)}`}
                      style={{
                        flex: 1, 
                        padding: "10px 14px", 
                        border: `1px solid ${T.success}60`, 
                        borderRadius: 6, 
                        fontSize: 14, 
                        fontWeight: 600, 
                        outline: "none", 
                        textAlign: "right", 
                        background: T.card, 
                        color: T.textPrimary,
                        fontFamily: T.font,
                      }}
                    />
                  </div>
                  <div style={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    alignItems: "center",
                    background: tenderedNum > 0 ? (changeDue >= 0 ? `${T.success}12` : `${T.error}12`) : T.card,
                    borderRadius: 6, 
                    padding: "10px 14px",
                  }}>
                    <span style={{
                      fontSize: 12, 
                      fontWeight: 600, 
                      color: tenderedNum > 0 ? (changeDue >= 0 ? T.success : T.error) : T.textMuted,
                    }}>
                      Change Due
                    </span>
                    <span style={{
                      fontSize: 18, 
                      fontWeight: 700, 
                      color: tenderedNum > 0 ? (changeDue >= 0 ? T.success : T.error) : T.textMuted,
                      fontFamily: "'Inter', monospace",
                    }}>
                      {tenderedNum > 0 ? (changeDue >= 0 ? `KES ${fmt(changeDue)}` : "Short") : "-"}
                    </span>
                  </div>
                </div>
              )}

              {/* Card panel */}
              {payMethod === "card" && (
                <div style={{
                  background: `${T.blue}08`, 
                  border: `1px solid ${T.blue}40`, 
                  borderRadius: 6, 
                  padding: 18, 
                  marginBottom: 18
                }}>
                  <div style={{
                    fontSize: 11, 
                    fontWeight: 600, 
                    color: T.blue, 
                    marginBottom: 8,
                    letterSpacing: 0.3,
                  }}>
                    CARD PAYMENT
                  </div>
                  <div style={{
                    fontSize: 12, 
                    color: T.textSecondary,
                    marginBottom: 12,
                  }}>
                    Present terminal to customer
                  </div>
                  <div style={{
                    display: "flex", 
                    justifyContent: "space-between", 
                    marginTop: 10, 
                    padding: "8px 12px", 
                    background: T.card, 
                    borderRadius: 6
                  }}>
                    <span style={{ fontSize: 11, color: T.textSecondary }}>Amount:</span>
                    <span style={{ fontSize: 15, fontWeight: 700, color: T.blue }}>
                      KES {fmt(billTotal)}
                    </span>
                  </div>
                </div>
              )}

              {/* Confirm button */}
              {(payMethod === "cash" || payMethod === "card" || (payMethod === "mpesa" && step === "confirm")) && (
                <button 
                  onClick={handleConfirmPayment}
                  disabled={payMethod === "cash" && tenderedNum > 0 && changeDue < 0}
                  style={{
                    width: "100%", 
                    padding: "14px", 
                    borderRadius: 6, 
                    border: `1px solid ${T.border}`,
                    background: (payMethod === "cash" && tenderedNum > 0 && changeDue < 0) ? T.textFaint : `linear-gradient(135deg, ${T.bg}, ${T.card})`,
                    color: (payMethod === "cash" && tenderedNum > 0 && changeDue < 0) ? T.textMuted : T.amber,
                    fontWeight: 700, 
                    fontSize: 14, 
                    cursor: (payMethod === "cash" && tenderedNum > 0 && changeDue < 0) ? "not-allowed" : "pointer",
                    fontFamily: T.font, 
                    letterSpacing: 0.5,
                    transition: "all 0.15s ease",
                  }}
                >
                  Confirm Payment - KES {fmt(billTotal)}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Processing overlay */}
        {processing && (
          <div style={{ ...overlay, position: "absolute" }}>
            <div style={{
              background: T.surface, 
              border: `1px solid ${T.border}`, 
              borderRadius: 8, 
              padding: "32px 48px", 
              textAlign: "center"
            }}>
              <div style={{
                fontSize: 32, 
                marginBottom: 12,
                color: T.amber,
              }}>
                -
              </div>
              <div style={{
                fontSize: 14, 
                fontWeight: 600,
                color: T.textPrimary,
              }}>
                Processing payment-
              </div>
            </div>
          </div>
        )}

        {/* Done screen */}
        {step === "done" && selectedInv && (
          <div style={{
            flex: 1, 
            display: "flex", 
            flexDirection: "column", 
            alignItems: "center", 
            justifyContent: "center", 
            padding: 32
          }}>
            <div style={{
              background: T.surface, 
              border: `1px solid ${T.border}`, 
              borderRadius: 8, 
              padding: "40px 48px", 
              textAlign: "center", 
              maxWidth: 400, 
              width: "100%"
            }}>
              <div style={{
                fontSize: 56, 
                marginBottom: 12,
                color: T.success,
              }}>
                -
              </div>
              <div style={{
                fontSize: 20, 
                fontWeight: 700, 
                color: T.success, 
                marginBottom: 6,
                letterSpacing: 0.5,
              }}>
                Payment Received
              </div>
              <div style={{
                fontSize: 12, 
                color: T.textMuted, 
                marginBottom: 2
              }}>
                Invoice #{selectedInv.id}
              </div>
              <div style={{
                fontSize: 11, 
                color: T.textFaint, 
                marginBottom: 4
              }}>
                Table {selectedInv.table} - Waiter: {selectedInv.waiter}
              </div>
              <div style={{
                fontSize: 28, 
                fontWeight: 700, 
                color: T.amber, 
                margin: "16px 0", 
                padding: "12px 20px", 
                background: T.card, 
                borderRadius: 6,
                fontFamily: "'Inter', monospace",
              }}>
                KES {fmt(selectedInv.finalTotal ?? selectedInv.total)}
              </div>
              <div style={{
                fontSize: 12, 
                color: T.textMuted, 
                marginBottom: payMethod === "cash" && changeDue > 0 ? 6 : 18,
                letterSpacing: 0.3,
              }}>
                {payMethod === "mpesa" ? `M-Pesa - ${mpesaPhone}` : payMethod === "card" ? "Card" : "Cash"}
              </div>
              {payMethod === "cash" && changeDue > 0 && (
                <div style={{
                  fontSize: 14, 
                  fontWeight: 700, 
                  color: T.success, 
                  background: `${T.success}12`, 
                  borderRadius: 6, 
                  padding: "8px 16px", 
                  marginBottom: 18
                }}>
                  Change: KES {fmt(changeDue)}
                </div>
              )}
              <div style={{ display: "flex", gap: 10 }}>
                <button 
                  onClick={() => setReceipt(openInvoices.find(i => i.id === selectedInv.id) || selectedInv)} 
                  style={{
                    ...actionBtn(T.card), 
                    flex: 1,
                    fontSize: 12,
                  }}
                >
                  Receipt
                </button>
                <button 
                  onClick={handleReset} 
                  style={{
                    ...actionBtn(T.amber), 
                    flex: 2, 
                    color: T.bg,
                    fontSize: 12,
                    fontWeight: 600,
                  }}
                >
                  Next Customer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Receipt Modal */}
      {receipt && (
        <ReceiptModal
          invoice={receipt}
          payMethod={payMethod}
          tendered={tenderedNum}
          change={Math.max(0, changeDue)}
          onClose={() => setReceipt(null)}
        />
      )}
    </div>
  );
}