import { useState, useEffect } from "react";
import { T } from "../posTheme";

// --- Helpers ------------------------------------------------------------------
function elapsedMinutes(createdDate) {
  // createdDate is stored as a time string like "14:32" - compare against now
  const now  = new Date();
  const [h, m] = (createdDate || "00:00").split(":").map(Number);
  const then = new Date();
  then.setHours(h, m, 0, 0);
  const diff = Math.floor((now - then) / 60000);
  return Math.max(0, diff);
}

function urgencyColor(mins) {
  if (mins >= 20) return "#8B3A3A"; // burgundy - very late
  if (mins >= 12) return "#B8860B"; // dark goldenrod - getting late
  return "#2E7D64";                  // deep teal - fine
}

function urgencyLabel(mins) {
  if (mins >= 20) return "CRITICAL";
  if (mins >= 12) return "DELAYED";
  return "ON TRACK";
}

const STATION_COLORS = {
  hot:    { bg:"#1A1515", border:"#8B3A3A", label:"Hot Kitchen",  text:"#8B3A3A"  },
  cold:   { bg:"#151A24", border:"#C5A059", label:"Cold Station",  text:"#C5A059"  },
  grill:  { bg:"#1A1810", border:"#B8860B", label:"Grill",        text:"#B8860B"  },
  bar:    { bg:"#18151A", border:"#C5A059", label:"Bar",           text:"#C5A059"  },
  pastry: { bg:"#151A15", border:"#2E7D64", label:"Pastry",        text:"#2E7D64"  },
  all:    { bg:T.surface, border:T.border,  label:"All Stations",    text:T.textPrimary },
};

// Category - station mapping
const CATEGORY_STATION = {
  mains:      "hot",
  starters:   "hot",
  soups:      "hot",
  grills:     "grill",
  salads:     "cold",
  desserts:   "pastry",
  beverages:  "bar",
  cocktails:  "bar",
  wines:      "bar",
};
const itemStation = (item) => CATEGORY_STATION[item.category] || "hot";

// --- Ticker (live clock shown on KDS) ----------------------------------------
function Ticker() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span style={{ 
      fontSize: 12, 
      color: T.textMuted, 
      fontVariantNumeric: "tabular-nums",
      fontFamily: "'Inter', monospace",
    }}>
      {time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
    </span>
  );
}

// --- Order Card ---------------------------------------------------------------
function OrderCard({ hold, onBump, onRecall }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 30000); // re-render every 30s
    return () => clearInterval(id);
  }, []);

  const mins   = elapsedMinutes(hold.createdDate);
  const uColor = urgencyColor(mins);
  const uLabel = urgencyLabel(mins);
  const isBumped = hold.status === "bumped";

  return (
    <div style={{
      background: isBumped ? "#0A0E1A" : T.card,
      border: `1px solid ${isBumped ? T.border : uColor}`,
      borderTop: `3px solid ${isBumped ? T.border : uColor}`,
      borderRadius: 6, 
      overflow: "hidden",
      opacity: isBumped ? 0.6 : 1,
      transition: "all 0.2s ease",
      boxShadow: mins >= 12 && !isBumped ? `0 2px 8px ${uColor}30` : "none",
    }}>
      {/* Card header */}
      <div style={{ 
        background: isBumped ? T.surface : `${uColor}10`, 
        padding: "12px 16px",
        borderBottom: `1px solid ${isBumped ? T.border : `${uColor}30`}`,
        display: "flex", 
        justifyContent: "space-between", 
        alignItems: "center" 
      }}>
        <div>
          <div style={{ 
            fontSize: 15, 
            fontWeight: 700, 
            color: isBumped ? T.textMuted : uColor,
            letterSpacing: "0.5px",
          }}>
            Table {hold.table}
          </div>
          <div style={{ 
            fontSize: 10, 
            color: T.textMuted, 
            marginTop: 2 
          }}>
            {hold.waiter} - #{hold.id.slice(-5)}
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ 
            fontSize: 10, 
            fontWeight: 600, 
            color: isBumped ? T.textMuted : uColor,
            letterSpacing: "0.5px",
          }}>
            {uLabel}
          </div>
          <div style={{ 
            fontSize: 13, 
            fontWeight: 700, 
            color: isBumped ? T.textMuted : uColor,
            fontFamily: "'Inter', monospace",
          }}>
            {mins}m
          </div>
          <div style={{ 
            fontSize: 9,  
            color: T.textMuted 
          }}>
            {hold.createdDate}
          </div>
        </div>
      </div>

      {/* Items */}
      <div style={{ padding: "12px 16px 10px" }}>
        {hold.items.map((item, i) => (
          <div key={i} style={{ 
            display: "flex", 
            alignItems: "flex-start", 
            gap: 10, 
            padding: "6px 0",
            borderBottom: i < hold.items.length-1 ? `1px solid ${T.border}` : "none" 
          }}>
            <span style={{ 
              fontSize: 14, 
              minWidth: 24,
              fontWeight: 500,
              color: isBumped ? T.textMuted : "#C5A059",
            }}>
              -{item.qty}
            </span>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ 
                  fontSize: 12, 
                  fontWeight: 500, 
                  color: isBumped ? T.textMuted : T.textPrimary 
                }}>
                  {item.name}
                </span>
              </div>
              {item.note && (
                <div style={{ 
                  fontSize: 9, 
                  color: "#B8860B", 
                  marginTop: 3, 
                  fontStyle: "italic",
                  letterSpacing: "0.3px",
                }}>
                  Note: {item.note}
                </div>
              )}
              {item.priceOverridden && (
                <div style={{ 
                  fontSize: 8, 
                  color: T.amber, 
                  marginTop: 1,
                  letterSpacing: "0.3px",
                }}>
                  Price override
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div style={{ padding: "10px 16px 14px", display: "flex", gap: 8 }}>
        {!isBumped ? (
          <button 
            onClick={() => onBump(hold.id)}
            style={{ 
              flex: 1, 
              padding: "12px", 
              borderRadius: 4, 
              border: "none", 
              cursor: "pointer",
              background: uColor, 
              color: uColor === "#B8860B" ? "#1A1A1A" : "#FFFFFF",
              fontWeight: 700, 
              fontSize: 13, 
              fontFamily: T.font, 
              letterSpacing: "0.5px",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.opacity = "0.9"; }}
            onMouseLeave={(e) => { e.currentTarget.style.opacity = "1"; }}
          >
            - FOOD READY - WAITER COLLECTING
          </button>
        ) : (
          <button 
            onClick={() => onRecall(hold.id)}
            style={{ 
              flex: 1, 
              padding: "10px", 
              borderRadius: 4, 
              border: `1px solid ${T.border}`, 
              cursor: "pointer",
              background: T.card, 
              color: T.textMuted, 
              fontWeight: 500, 
              fontSize: 11, 
              fontFamily: T.font,
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = T.hover;
              e.currentTarget.style.color = T.textPrimary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = T.card;
              e.currentTarget.style.color = T.textMuted;
            }}
          >
            Recall Order
          </button>
        )}
      </div>
    </div>
  );
}

// --- MAIN KDS COMPONENT -------------------------------------------------------
export default function KitchenDisplay({ holdList, setHoldList }) {
  const [station,    setStation]    = useState("all");
  const [showBumped, setShowBumped] = useState(false);
  const [tick,       setTick]       = useState(0);

  // Re-render every 60s to keep elapsed times fresh
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60000);
    return () => clearInterval(id);
  }, []);

  const holds = (holdList || []);

  // Filter by station
  const visibleHolds = holds.filter(h => {
    const matchStation = station === "all"
      ? true
      : h.items.some(i => itemStation(i) === station);
    const matchBumped  = showBumped ? true : h.status !== "bumped";
    // Only show pending/bumped, not billed/paid
    return (h.status === "pending" || h.status === "bumped") && matchStation && matchBumped;
  });

  const pendingCount = holds.filter(h => h.status === "pending").length;
  const bumpedCount  = holds.filter(h => h.status === "bumped").length;

  // Elapsed minutes for alerting
  const lateCount = holds.filter(h => h.status === "pending" && elapsedMinutes(h.createdDate) >= 12).length;

  const handleBump = async (id) => {
    setHoldList(p => p.map(h => h.id === id ? { ...h, status: "bumped", bumpedAt: new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}) } : h));
    try {
      const { posApi } = await import("../api/index.js");
      await posApi.updateHold(id, { status: "bumped" });
    } catch (err) { console.error("Bump failed:", err.message); }
  };
  const handleRecall = async (id) => {
    setHoldList(p => p.map(h => h.id === id ? { ...h, status: "pending", bumpedAt: null } : h));
    try {
      const { posApi } = await import("../api/index.js");
      await posApi.updateHold(id, { status: "pending" });
    } catch (err) { console.error("Recall failed:", err.message); }
  };

  const stationsWithOrders = ["all", ...Object.keys(STATION_COLORS).filter(s => {
    if (s === "all") return false;
    return holds.some(h => h.status === "pending" && h.items.some(i => itemStation(i) === s));
  })];

  return (
    <div style={{ 
      flex: 1, 
      display: "flex", 
      flexDirection: "column", 
      overflow: "hidden",
      background: "#0A0E1A", 
      fontFamily: T.font, 
      color: T.textPrimary 
    }}>

      {/* -- Top bar -- */}
      <div style={{ 
        background: "#0A0E1A", 
        borderBottom: "1px solid #1E2A3A", 
        padding: "12px 24px",
        display: "flex", 
        alignItems: "center", 
        gap: 20, 
        flexShrink: 0 
      }}>
        <div style={{ 
          fontSize: 14, 
          fontWeight: 600, 
          color: T.amber, 
          letterSpacing: 1.5,
          textTransform: "uppercase",
        }}>
          Kitchen Display
        </div>

        {/* Live stats */}
        <div style={{ display: "flex", gap: 12, flex: 1 }}>
          <div style={{ 
            background: T.card, 
            borderRadius: 4, 
            padding: "5px 14px", 
            border: `1px solid ${T.border}` 
          }}>
            <span style={{ fontSize: 10, color: T.textMuted, letterSpacing: "0.5px" }}>
              PENDING 
            </span>
            <span style={{ 
              fontSize: 16, 
              fontWeight: 700, 
              color: T.amber,
              fontFamily: "'Inter', monospace",
            }}>
              {pendingCount}
            </span>
          </div>
          {lateCount > 0 && (
            <div style={{ 
              background: "#8B3A3A22", 
              borderRadius: 4, 
              padding: "5px 14px", 
              border: "1px solid #8B3A3A66",
              animation: "pulse 1s infinite" 
            }}>
              <span style={{ fontSize: 10, color: "#8B3A3A", letterSpacing: "0.5px" }}>
                DELAYED 
              </span>
              <span style={{ 
                fontSize: 16, 
                fontWeight: 700, 
                color: "#8B3A3A",
                fontFamily: "'Inter', monospace",
              }}>
                {lateCount}
              </span>
            </div>
          )}
          {bumpedCount > 0 && (
            <div style={{ 
              background: T.card, 
              borderRadius: 4, 
              padding: "5px 14px", 
              border: `1px solid ${T.border}` 
            }}>
              <span style={{ fontSize: 10, color: T.textMuted, letterSpacing: "0.5px" }}>
                COMPLETED 
              </span>
              <span style={{ 
                fontSize: 14, 
                fontWeight: 600, 
                color: T.textMuted,
                fontFamily: "'Inter', monospace",
              }}>
                {bumpedCount}
              </span>
            </div>
          )}
        </div>

        {/* Show bumped toggle */}
        <button 
          onClick={() => setShowBumped(v => !v)} 
          style={{
            padding: "6px 16px", 
            borderRadius: 4, 
            border: `1px solid ${showBumped ? T.amber : T.border}`,
            background: showBumped ? `${T.amber}20` : T.card, 
            color: showBumped ? T.amber : T.textMuted,
            fontSize: 11, 
            fontWeight: 600, 
            cursor: "pointer", 
            fontFamily: T.font,
            letterSpacing: "0.5px",
            transition: "all 0.2s ease",
          }}
        >
          {showBumped ? "Hide" : "Show"} Completed
        </button>

        <Ticker />
      </div>

      {/* -- Station tabs -- */}
      <div style={{ 
        background: "#0A0E1A", 
        borderBottom: `1px solid ${T.border}`,
        display: "flex", 
        gap: 0, 
        overflowX: "auto", 
        flexShrink: 0,
        paddingLeft: 20,
      }}>
        {stationsWithOrders.map(s => {
          const sc = STATION_COLORS[s] || STATION_COLORS.all;
          const count = s === "all" ? pendingCount
            : holds.filter(h => h.status==="pending" && h.items.some(i => itemStation(i) === s)).length;
          return (
            <button 
              key={s} 
              onClick={() => setStation(s)} 
              style={{
                padding: "12px 24px", 
                border: "none", 
                cursor: "pointer", 
                fontWeight: 600, 
                fontSize: 12,
                background: "transparent", 
                whiteSpace: "nowrap", 
                fontFamily: T.font,
                color: station === s ? sc.text : T.textMuted,
                borderBottom: `2px solid ${station === s ? sc.text : "transparent"}`,
                transition: "all 0.15s ease",
                letterSpacing: "0.5px",
              }}
            >
              {sc.label}
              {count > 0 && (
                <span style={{ 
                  marginLeft: 8, 
                  background: sc.text, 
                  color: sc.text === T.amber ? "#0A0E1A" : "#FFFFFF",
                  fontSize: 10, 
                  fontWeight: 700, 
                  borderRadius: 10, 
                  padding: "1px 7px",
                  fontFamily: "'Inter', monospace",
                }}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* -- Order grid -- */}
      <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
        {visibleHolds.length === 0 ? (
          <div style={{ 
            flex: 1, 
            display: "flex", 
            flexDirection: "column", 
            alignItems: "center",
            justifyContent: "center", 
            height: "60vh", 
            color: T.textFaint 
          }}>
            <div style={{ 
              width: 80,
              height: 80,
              borderRadius: "50%",
              background: "rgba(45, 158, 107, 0.08)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 20px",
              border: "1px solid rgba(45, 158, 107, 0.2)",
            }}>
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#2E7D64" strokeWidth="1.5">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </div>
            <div style={{ 
              fontSize: 18, 
              fontWeight: 600, 
              color: T.textMuted,
              letterSpacing: "0.5px",
            }}>
              {pendingCount === 0 ? "All Orders Completed" : "No Orders for This Station"}
            </div>
            <div style={{ fontSize: 12, marginTop: 8, color: T.textMuted }}>
              {pendingCount === 0 ? "Kitchen is up to date" : `${pendingCount} pending in other stations`}
            </div>
          </div>
        ) : (
          <div style={{ 
            display: "grid", 
            gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", 
            gap: 16 
          }}>
            {/* Sort: late first, then by time */}
            {[...visibleHolds]
              .sort((a,b) => {
                if (a.status === "bumped" && b.status !== "bumped") return 1;
                if (b.status === "bumped" && a.status !== "bumped") return -1;
                return elapsedMinutes(b.createdDate) - elapsedMinutes(a.createdDate);
              })
              .map(h => (
                <OrderCard key={h.id} hold={h} onBump={handleBump} onRecall={handleRecall} />
              ))
            }
          </div>
        )}
      </div>

      {/* Pulse animation keyframes */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
      `}</style>
    </div>
  );
}