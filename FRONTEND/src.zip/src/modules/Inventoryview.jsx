import { useState, useCallback, useMemo, useEffect } from "react";
import { fmt, fmtK } from "../utils";

// --- Google Fonts ---------------------------------------------------------
const FONTS = "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Cormorant+Garamond:wght@400;500;600&display=swap";

// Simple physical-vs-system variance (different from the variance report in utils)
const computeVariance = (system, physical) =>
  parseFloat(physical) - parseFloat(system);

// classifyExpiry - mirrors utils.js signature exactly
const classifyExpiry = (dateStr) => {
  if (!dateStr) return { status:"unknown", label:"-", color:"#94a3b8", bg:"#f1f5f9" };
  const days = Math.round((new Date(dateStr) - new Date()) / 86400000);
  if (days < 0)  return { status:"expired",  days, label:"Expired",       color:"#8B3A3A", bg:"#FEF2F2" };
  if (days === 0) return { status:"expiring", days, label:"Expires Today", color:"#DC2626", bg:"#FEF2F2" };
  if (days <= 3)  return { status:"critical", days, label:`${days}d left`, color:"#B8860B", bg:"#FFF7ED" };
  if (days <= 7)  return { status:"warning",  days, label:`${days}d left`, color:"#EAB308", bg:"#FEFCE8" };
  return               { status:"ok",         days, label:`${days}d left`, color:"#2E7D64", bg:"#F0FDF4" };
};

// --- Sample inventory -----------------------------------------------------
const SAMPLE_INVENTORY = [
  { id:1,  name:"Beef (kg)",           qty:18.5, unit:"kg",     costPerUnit:850,   expiryDate:"2026-05-08", category:"Proteins",   branch:"restaurant" },
  { id:2,  name:"Tilapia (kg)",        qty:12.0, unit:"kg",     costPerUnit:650,   expiryDate:"2026-05-06", category:"Proteins",   branch:"restaurant" },
  { id:3,  name:"Ugali Flour (kg)",    qty:50.0, unit:"kg",     costPerUnit:120,   expiryDate:"2026-08-15", category:"Grains",     branch:"restaurant" },
  { id:4,  name:"Cooking Oil (L)",     qty:24.0, unit:"L",      costPerUnit:280,   expiryDate:"2026-10-01", category:"Oils",       branch:"restaurant" },
  { id:5,  name:"Sukuma Wiki (bunch)", qty:30,   unit:"pcs",    costPerUnit:30,    expiryDate:"2026-05-07", category:"Vegetables", branch:"restaurant" },
  { id:6,  name:"Tomatoes (kg)",       qty:15.0, unit:"kg",     costPerUnit:90,    expiryDate:"2026-05-09", category:"Vegetables", branch:"restaurant" },
  { id:7,  name:"Pilau Masala",        qty:8.0,  unit:"kg",     costPerUnit:450,   expiryDate:"2026-12-01", category:"Spices",     branch:"restaurant" },
  { id:8,  name:"Coca-Cola (crate)",   qty:6,    unit:"crates", costPerUnit:2400,  expiryDate:"2026-09-30", category:"Beverages",  branch:"restaurant" },
  { id:9,  name:"Tusker Lager",        qty:4,    unit:"crates", costPerUnit:3200,  expiryDate:"2026-07-15", category:"Beverages",  branch:"restaurant" },
  { id:10, name:"Chapati Flour",       qty:25.0, unit:"kg",     costPerUnit:130,   expiryDate:"2026-06-20", category:"Grains",     branch:"restaurant" },
  { id:11, name:"Gin (750ml)",         qty:12,   unit:"bottles",costPerUnit:2200,  expiryDate:"2027-01-01", category:"Spirits",    branch:"restaurant" },
  { id:12, name:"Tonic Water",         qty:48,   unit:"cans",   costPerUnit:150,   expiryDate:"2026-11-30", category:"Beverages",  branch:"restaurant" },
  { id:13, name:"Breakfast Eggs",      qty:60,   unit:"pcs",    costPerUnit:18,    expiryDate:"2026-05-10", category:"Produce",    branch:"restaurant" },
];

// Sample batches per ingredient for the drill-down panel
const SAMPLE_BATCHES = {
  1: [
    { batchNo:"BEF-081", supplier:"Fresh Farm Produce", remaining:8.5,  expiry:"2026-05-08" },
    { batchNo:"BEF-082", supplier:"Fresh Farm Produce", remaining:10.0, expiry:"2026-05-12" },
  ],
  2: [
    { batchNo:"FIS-031", supplier:"Coastal Fish Co.",   remaining:12.0, expiry:"2026-05-06" },
  ],
  3: [
    { batchNo:"FLR-021", supplier:"Nakumatt Wholesale", remaining:30.0, expiry:"2026-08-15" },
    { batchNo:"FLR-022", supplier:"Nakumatt Wholesale", remaining:20.0, expiry:"2026-09-01" },
  ],
  8: [
    { batchNo:"COL-011", supplier:"Coca-Cola Dist.",    remaining:3,    expiry:"2026-09-30" },
    { batchNo:"COL-012", supplier:"Coca-Cola Dist.",    remaining:3,    expiry:"2026-10-15" },
  ],
  9: [
    { batchNo:"KBL-041", supplier:"Kenya Breweries",    remaining:4,    expiry:"2026-07-15" },
  ],
};

// --- Skeleton Loader ------------------------------------------------------
function TableSkeleton() {
  return (
    <div style={{ padding:"0 0 8px" }}>
      {[1,2,3,4,5,6].map(i => (
        <div key={i} style={{
          height:52, background:"#F3F4F6", borderRadius:6,
          marginBottom:6, opacity: 1 - i * 0.12,
          animation:"skeletonPulse 1.4s ease-in-out infinite",
        }}/>
      ))}
    </div>
  );
}

// --- Expiry Badge ---------------------------------------------------------
function ExpiryBadge({ dateStr }) {
  const e = classifyExpiry(dateStr);
  return (
    <span style={{ 
      background:e.bg, 
      color:e.color,
      fontSize:10, 
      fontWeight:600, 
      padding:"3px 10px",
      borderRadius:4, 
      letterSpacing:0.3, 
      whiteSpace:"nowrap" 
    }}>
      {e.label}
    </span>
  );
}

// --- Variance Cell --------------------------------------------------------
function VarianceCell({ variance, shrinkageValue }) {
  if (variance === null || isNaN(variance)) return <span style={{ color:"#D1D5DB" }}>-</span>;
  const isPos  = variance > 0;
  const isZero = variance === 0;
  const color  = isZero ? "#6B7280" : isPos ? "#2E7D64" : "#8B3A3A";
  const bg     = isZero ? "#F3F4F6" : isPos ? "#ECFDF5" : "#FEF2F2";
  const arrow  = isZero ? "-" : isPos ? "-" : "-";
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:2 }}>
      <span style={{ 
        background:bg, 
        color, 
        fontWeight:600, 
        fontSize:11,
        padding:"2px 8px", 
        borderRadius:4, 
        display:"inline-flex",
        alignItems:"center", 
        gap:3, 
        fontFamily:"'Inter', monospace" 
      }}>
        {arrow} {isPos ? "+" : ""}{variance.toFixed(2)}
      </span>
      {!isZero && (
        <span style={{ fontSize:10, color, fontWeight:500 }}>
          {isPos ? "surplus" : "loss"} {fmtK(Math.abs(shrinkageValue))}
        </span>
      )}
    </div>
  );
}

// --- Audit Input ----------------------------------------------------------
function AuditInput({ value, onChange }) {
  return (
    <input 
      type="number" 
      min="0" 
      step="0.01" 
      value={value ?? ""} 
      onChange={e => onChange(e.target.value)}
      placeholder="Count"
      style={{ 
        width:90, 
        border:"1px solid #C5A059", 
        borderRadius:4,
        padding:"5px 8px", 
        fontSize:12, 
        textAlign:"center",
        fontFamily:"'Inter', monospace", 
        outline:"none",
        background:"#FEF9F0", 
        color:"#A0823A", 
        fontWeight:500 
      }}
    />
  );
}

// --- Audit Summary Banner -------------------------------------------------
function AuditSummary({ items, auditData }) {
  const summary = useMemo(() => {
    let totalLoss=0, totalSurplus=0, countAudited=0, countDiscrepancy=0;
    items.forEach(item => {
      const physical = auditData[item.id];
      if (physical === undefined || physical === "") return;
      countAudited++;
      const v = computeVariance(item.qty, physical);
      const val = v * item.costPerUnit;
      if (v < 0) { totalLoss += Math.abs(val); countDiscrepancy++; }
      if (v > 0) { totalSurplus += val; }
    });
    return { totalLoss, totalSurplus, countAudited, countDiscrepancy };
  }, [items, auditData]);

  return (
    <div style={{ 
      background:"linear-gradient(135deg, #1A1A1A 0%, #2C3E50 100%)",
      borderRadius:8, 
      padding:"16px 24px", 
      marginBottom:20,
      display:"flex", 
      flexWrap:"wrap", 
      gap:30 
    }}>
      {[
        { label:"Items Audited",    value:`${summary.countAudited} / ${items.length}`, icon:"-" },
        { label:"Discrepancies",    value:summary.countDiscrepancy,                    icon:"#", warn: summary.countDiscrepancy > 0 },
        { label:"Shrinkage (Loss)", value:fmtK(summary.totalLoss),                    icon:"-", warn: summary.totalLoss > 0 },
        { label:"Surplus Found",    value:fmtK(summary.totalSurplus),                 icon:"-", good: summary.totalSurplus > 0 },
      ].map(kpi => (
        <div key={kpi.label} style={{ minWidth:130 }}>
          <div style={{ 
            fontSize:10, 
            color:"rgba(255,255,255,0.5)", 
            letterSpacing:1, 
            textTransform:"uppercase",
            fontFamily:"'Inter', sans-serif",
          }}>
            {kpi.icon} {kpi.label}
          </div>
          <div style={{
            fontSize:18, 
            fontWeight:600, 
            fontFamily:"'Inter', monospace", 
            marginTop:3,
            color: kpi.warn ? "#FCA5A5" : kpi.good ? "#86EFAC" : "rgba(255,255,255,0.9)"
          }}>{kpi.value}</div>
        </div>
      ))}
    </div>
  );
}

// --- Batch Drill-Down Side Panel ------------------------------------------
function BatchPanel({ item, onClose }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(t);
  }, []);

  const handleClose = () => {
    setVisible(false);
    setTimeout(onClose, 300);
  };

  const batches = SAMPLE_BATCHES[item?.id] || [];

  return (
    <>
      {/* Backdrop */}
      <div onClick={handleClose} style={{
        position:"fixed", 
        inset:0, 
        background:"rgba(0,0,0,0.4)",
        zIndex:200, 
        opacity: visible ? 1 : 0, 
        transition:"opacity 0.3s ease",
        backdropFilter:"blur(2px)",
      }}/>
      
      {/* Panel */}
      <div style={{
        position:"fixed", 
        right:0, 
        top:0, 
        bottom:0, 
        width:400,
        background:"#FFFFFF", 
        zIndex:201, 
        overflowY:"auto",
        boxShadow:"-4px 0 20px rgba(0,0,0,0.1)",
        transform: visible ? "translateX(0)" : "translateX(100%)",
        transition:"transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        display:"flex", 
        flexDirection:"column",
      }}>
        {/* Panel Header */}
        <div style={{ 
          background:"linear-gradient(135deg, #C5A059, #A0823A)",
          padding:"24px", 
          display:"flex", 
          alignItems:"flex-start", 
          gap:12 
        }}>
          <div style={{ flex:1 }}>
            <div style={{ 
              fontSize:10, 
              color:"rgba(255,255,255,0.6)", 
              letterSpacing:1.5,
              textTransform:"uppercase", 
              marginBottom:6,
              fontFamily:"'Inter', sans-serif",
            }}>
              Batch Details
            </div>
            <div style={{ 
              fontSize:18, 
              fontWeight:600, 
              color:"#FFFFFF",
              fontFamily:"'Inter', sans-serif",
            }}>
              {item.name}
            </div>
            <div style={{ 
              fontSize:11, 
              color:"rgba(255,255,255,0.7)", 
              marginTop:4 
            }}>
              {item.category} - {item.unit}
            </div>
          </div>
          <button 
            onClick={handleClose} 
            style={{
              background:"rgba(255,255,255,0.15)", 
              border:"none",
              borderRadius:4, 
              width:32, 
              height:32, 
              color:"#FFFFFF",
              cursor:"pointer", 
              fontSize:18, 
              display:"flex",
              alignItems:"center", 
              justifyContent:"center",
              transition:"background 0.15s"
            }}
            onMouseEnter={e => e.currentTarget.style.background="rgba(255,255,255,0.25)"}
            onMouseLeave={e => e.currentTarget.style.background="rgba(255,255,255,0.15)"}
          >
            -
          </button>
        </div>

        {/* Summary strip */}
        <div style={{ 
          background:"#F8F8F8", 
          borderBottom:"1px solid #E5E0D5",
          padding:"16px 24px", 
          display:"flex", 
          gap:30 
        }}>
          <div>
            <div style={{ 
              fontSize:9, 
              color:"#7A7A7A", 
              fontWeight:600, 
              textTransform:"uppercase", 
              letterSpacing:0.8 
            }}>
              System Qty
            </div>
            <div style={{ 
              fontSize:15, 
              fontWeight:600, 
              fontFamily:"'Inter', monospace", 
              color:"#1A1A1A", 
              marginTop:2 
            }}>
              {item.qty} {item.unit}
            </div>
          </div>
          <div>
            <div style={{ 
              fontSize:9, 
              color:"#7A7A7A", 
              fontWeight:600, 
              textTransform:"uppercase", 
              letterSpacing:0.8 
            }}>
              Stock Value
            </div>
            <div style={{ 
              fontSize:15, 
              fontWeight:600, 
              fontFamily:"'Inter', monospace", 
              color:"#1A1A1A", 
              marginTop:2 
            }}>
              {fmtK(item.qty * item.costPerUnit)}
            </div>
          </div>
          <div>
            <div style={{ 
              fontSize:9, 
              color:"#7A7A7A", 
              fontWeight:600, 
              textTransform:"uppercase", 
              letterSpacing:0.8 
            }}>
              Unit Cost
            </div>
            <div style={{ 
              fontSize:15, 
              fontWeight:600, 
              fontFamily:"'Inter', monospace", 
              color:"#1A1A1A", 
              marginTop:2 
            }}>
              {fmtK(item.costPerUnit)}/{item.unit}
            </div>
          </div>
        </div>

        {/* Batches List */}
        <div style={{ flex:1, padding:"20px 24px" }}>
          <div style={{ 
            fontSize:11, 
            fontWeight:600, 
            color:"#4A4A4A",
            letterSpacing:0.8, 
            textTransform:"uppercase", 
            marginBottom:16 
          }}>
            Active Batches ({batches.length})
          </div>

          {batches.length === 0 ? (
            <div style={{ 
              textAlign:"center", 
              padding:40, 
              color:"#7A7A7A", 
              fontSize:12 
            }}>
              No batch records for this item
            </div>
          ) : (
            batches.map((batch, idx) => {
              const expInfo = classifyExpiry(batch.expiry);
              return (
                <div key={batch.batchNo} style={{
                  border:"1px solid #E5E0D5", 
                  borderRadius:6,
                  padding:"16px", 
                  marginBottom:12,
                  opacity: 0, 
                  animation:`batchSlideIn 0.3s ease ${idx * 0.08}s forwards`,
                }}>
                  <div style={{ 
                    display:"flex", 
                    alignItems:"center", 
                    justifyContent:"space-between", 
                    marginBottom:12 
                  }}>
                    <div>
                      <div style={{ 
                        fontSize:12, 
                        fontWeight:600, 
                        color:"#C5A059",
                        fontFamily:"'Inter', monospace" 
                      }}>
                        {batch.batchNo}
                      </div>
                      <div style={{ 
                        fontSize:10, 
                        color:"#7A7A7A", 
                        marginTop:2 
                      }}>
                        {batch.supplier}
                      </div>
                    </div>
                    {/* Expiry status badge */}
                    <span style={{ 
                      background:expInfo.bg, 
                      color:expInfo.color,
                      fontSize:10, 
                      fontWeight:600, 
                      padding:"2px 8px",
                      borderRadius:4, 
                      letterSpacing:0.3 
                    }}>
                      {expInfo.status === "ok" ? "Safe" :
                       expInfo.status === "expired" ? "Expired" : expInfo.label}
                    </span>
                  </div>

                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                    <div style={{ 
                      background:"#F8F8F8", 
                      borderRadius:4, 
                      padding:"8px 12px" 
                    }}>
                      <div style={{ 
                        fontSize:9, 
                        color:"#7A7A7A", 
                        fontWeight:600, 
                        textTransform:"uppercase", 
                        letterSpacing:0.5 
                      }}>
                        Qty Remaining
                      </div>
                      <div style={{ 
                        fontSize:13, 
                        fontWeight:600, 
                        color:"#1A1A1A",
                        fontFamily:"'Inter', monospace", 
                        marginTop:3 
                      }}>
                        {batch.remaining} {item.unit}
                      </div>
                    </div>
                    <div style={{ 
                      background:"#F8F8F8", 
                      borderRadius:4, 
                      padding:"8px 12px" 
                    }}>
                      <div style={{ 
                        fontSize:9, 
                        color:"#7A7A7A", 
                        fontWeight:600, 
                        textTransform:"uppercase", 
                        letterSpacing:0.5 
                      }}>
                        Expires
                      </div>
                      <div style={{ 
                        fontSize:13, 
                        fontWeight:600, 
                        color:expInfo.color,
                        fontFamily:"'Inter', monospace", 
                        marginTop:3 
                      }}>
                        {batch.expiry}
                      </div>
                    </div>
                  </div>

                  {/* Countdown bar */}
                  <div style={{ marginTop:12 }}>
                    <div style={{ 
                      height:3, 
                      background:"#E5E0D5", 
                      borderRadius:2, 
                      overflow:"hidden" 
                    }}>
                      <div style={{
                        height:"100%", 
                        borderRadius:2,
                        background: expInfo.color,
                        width: `${Math.max(0, Math.min(100, (expInfo.days / 30) * 100))}%`,
                        transition:"width 0.6s ease",
                      }}/>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </>
  );
}

// --- Category Group --------------------------------------------------------
function CategoryGroup({ category, items, auditMode, auditData, onPhysicalChange, onRowClick }) {
  return (
    <div style={{ marginBottom:6 }}>
      <div style={{ 
        background:"#F8F8F8", 
        borderLeft:"3px solid #C5A059",
        padding:"6px 20px", 
        fontSize:10, 
        fontWeight:600,
        color:"#C5A059", 
        letterSpacing:1, 
        textTransform:"uppercase" 
      }}>
        {category}
      </div>
      {items.map(item => {
        const physical = auditData[item.id];
        const hasPhysical = physical !== "" && physical !== undefined;
        const variance = hasPhysical ? computeVariance(item.qty, physical) : null;
        const shrinkageValue = variance !== null ? variance * item.costPerUnit : 0;
        const rowBg = !auditMode ? "#FFFFFF"
          : !hasPhysical ? "#FFFBEB"
          : variance === 0 ? "#ECFDF5"
          : variance > 0 ? "#ECFDF5"
          : "#FEF2F2";

        return (
          <div key={item.id}
            onClick={() => !auditMode && onRowClick(item)}
            style={{
              display:"grid",
              gridTemplateColumns: auditMode
                ? "2fr 90px 80px 110px 130px 130px"
                : "2fr 90px 80px 110px 130px",
              gap:0, 
              background:rowBg,
              borderBottom:"1px solid #F0EDE6",
              alignItems:"center",
              transition:"background 0.2s ease",
              cursor: auditMode ? "default" : "pointer",
            }}
            onMouseEnter={e => { 
              if (!auditMode) { 
                e.currentTarget.style.background="#F5F2EB"; 
              } 
            }}
            onMouseLeave={e => { 
              if (!auditMode) { 
                e.currentTarget.style.background=rowBg; 
              } 
            }}
          >
            <Cell>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ 
                  fontSize:12, 
                  fontWeight:500, 
                  color:"#1A1A1A" 
                }}>
                  {item.name}
                </span>
                {!auditMode && (
                  <span style={{ 
                    fontSize:9, 
                    color:"#C5A059", 
                    fontWeight:500,
                    opacity:0.6,
                  }}>
                    view batches -
                  </span>
                )}
              </div>
            </Cell>
            <Cell mono>{item.qty} {item.unit}</Cell>
            <Cell><ExpiryBadge dateStr={item.expiryDate}/></Cell>
            <Cell mono>{fmtK(item.qty * item.costPerUnit)}</Cell>
            <Cell mono>
              {fmtK(item.costPerUnit)}
              <span style={{ fontSize:10, color:"#7A7A7A" }}>/{item.unit}</span>
            </Cell>
            {auditMode && (
              <Cell>
                <div style={{ display:"flex", flexDirection:"column", gap:4, padding:"6px 0" }}>
                  <AuditInput value={auditData[item.id]} onChange={val => onPhysicalChange(item.id, val)}/>
                  <VarianceCell variance={variance} shrinkageValue={shrinkageValue}/>
                </div>
              </Cell>
            )}
          </div>
        );
      })}
    </div>
  );
}

function Cell({ children, mono }) {
  return (
    <div style={{ 
      padding:"10px 16px", 
      fontSize:12,
      fontFamily: mono ? "'Inter', monospace" : "'Inter', sans-serif",
      color: mono ? "#4A4A4A" : "#1A1A1A" 
    }}>
      {children}
    </div>
  );
}

// --- Main InventoryView ----------------------------------------------------
export default function InventoryView() {
  const [auditMode,    setAuditMode]    = useState(false);
  const [auditData,    setAuditData]    = useState({});
  const [search,       setSearch]       = useState("");
  const [filterCat,    setFilterCat]    = useState("All");
  const [selectedItem, setSelectedItem] = useState(null);
  const [loading,      setLoading]      = useState(true);

  // Simulate table skeleton load
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 550);
    return () => clearTimeout(t);
  }, []);

  // Filter inventory
  const branchFiltered = SAMPLE_INVENTORY;

  const categories = useMemo(() =>
    ["All", ...new Set(SAMPLE_INVENTORY.map(i => i.category))],
    []
  );

  const filtered = useMemo(() =>
    SAMPLE_INVENTORY
      .filter(i =>
        (filterCat === "All" || i.category === filterCat) &&
        i.name.toLowerCase().includes(search.toLowerCase())
      )
      .sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate)),
    [search, filterCat]
  );

  const grouped = useMemo(() => {
    const map = {};
    filtered.forEach(i => {
      if (!map[i.category]) map[i.category] = [];
      map[i.category].push(i);
    });
    return map;
  }, [filtered]);

  const handlePhysicalChange = useCallback((id, val) => {
    setAuditData(prev => ({ ...prev, [id]: val }));
  }, []);

  const startAudit    = () => { setAuditData({}); setAuditMode(true); };
  const completeAudit = () => setAuditMode(false);

  const headerCols = auditMode
    ? ["Item Name","System Qty","Expiry","Stock Value","Unit Cost","Physical Count / Variance"]
    : ["Item Name","System Qty","Expiry","Stock Value","Unit Cost"];
  const gridTemplate = auditMode
    ? "2fr 90px 80px 110px 130px 130px"
    : "2fr 90px 80px 110px 130px";

  return (
    <div style={{ 
      fontFamily:"'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      maxWidth:1200, 
      margin:"0 auto", 
      padding:28,
      background:"#F5F2EB",
      minHeight:"100vh",
    }}>
      <link rel="stylesheet" href={FONTS}/>
      <style>{`
        @keyframes skeletonPulse {
          0%,100% { opacity:1 } 50% { opacity:0.5 }
        }
        @keyframes batchSlideIn {
          from { opacity:0; transform:translateY(8px) }
          to   { opacity:1; transform:translateY(0) }
        }
      `}</style>

      {/* -- Page Header -- */}
      <div style={{ 
        display:"flex", 
        alignItems:"center",
        justifyContent:"space-between", 
        marginBottom:24,
        flexWrap:"wrap", 
        gap:16,
        borderBottom:"1px solid #E5E0D5",
        paddingBottom:20,
      }}>
        <div>
          <div style={{ 
            fontSize:24, 
            fontWeight:600, 
            color:"#1A1A1A", 
            letterSpacing:"0.5px",
            fontFamily:"'Cormorant Garamond', serif",
          }}>
            Inventory Management
          </div>
          <div style={{ 
            fontSize:11, 
            color:"#7A7A7A", 
            marginTop:4,
            letterSpacing:"0.3px",
          }}>
            FEFO - {filtered.length} items - Damascus Hotel
          </div>
        </div>

        <div style={{ display:"flex", gap:12, alignItems:"center", flexWrap:"wrap" }}>
          {auditMode ? (
            <>
              <div style={{ 
                padding:"6px 16px", 
                borderRadius:4, 
                background:"#FFFBEB",
                color:"#B8860B", 
                fontSize:11, 
                fontWeight:600,
                display:"flex", 
                alignItems:"center", 
                gap:8,
                letterSpacing:"0.5px",
              }}>
                <span style={{ 
                  width:6, 
                  height:6, 
                  borderRadius:"50%",
                  background:"#B8860B", 
                  display:"inline-block",
                  animation:"skeletonPulse 1.2s infinite" 
                }}/>
                AUDIT IN PROGRESS
              </div>
              <button 
                onClick={completeAudit} 
                style={{
                  padding:"8px 20px",
                  borderRadius:4,
                  border:"1px solid #C5A059",
                  background:"#FFFFFF",
                  color:"#C5A059",
                  fontWeight:600,
                  fontSize:12,
                  cursor:"pointer",
                  transition:"all 0.2s ease",
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.background="#C5A059";
                  e.currentTarget.style.color="#FFFFFF";
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.background="#FFFFFF";
                  e.currentTarget.style.color="#C5A059";
                }}
              >
                Complete Audit
              </button>
            </>
          ) : (
            <button 
              onClick={startAudit} 
              style={{
                padding:"8px 20px",
                borderRadius:4,
                border:"none",
                background:"#C5A059",
                color:"#FFFFFF",
                fontWeight:600,
                fontSize:12,
                cursor:"pointer",
                transition:"all 0.2s ease",
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background="#A0823A";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background="#C5A059";
              }}
            >
              Start Audit
            </button>
          )}
        </div>
      </div>

      {/* -- Audit Summary -- */}
      {auditMode && <AuditSummary items={filtered} auditData={auditData}/>}

      {/* -- Filters -- */}
      <div style={{ display:"flex", gap:12, marginBottom:20, flexWrap:"wrap" }}>
        <input 
          placeholder="Search inventory..." 
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ 
            flex:1, 
            minWidth:200, 
            border:"1px solid #E5E0D5", 
            borderRadius:4,
            padding:"9px 16px", 
            fontSize:12, 
            outline:"none", 
            fontFamily:"'Inter', sans-serif",
            background:"#FFFFFF",
          }}
        />
        <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
          {categories.map(cat => (
            <button 
              key={cat} 
              onClick={() => setFilterCat(cat)} 
              style={{
                padding:"6px 16px", 
                borderRadius:4, 
                fontSize:11, 
                fontWeight:500,
                border:"1px solid",
                borderColor: filterCat===cat ? "#C5A059" : "#E5E0D5",
                background: filterCat===cat ? "#C5A059" : "#FFFFFF",
                color: filterCat===cat ? "#FFFFFF" : "#4A4A4A",
                cursor:"pointer", 
                fontFamily:"'Inter', sans-serif",
                transition:"all 0.2s ease",
              }}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* -- Table -- */}
      <div style={{ 
        borderRadius:6, 
        border:"1px solid #E5E0D5",
        overflow:"hidden", 
        background:"#FFFFFF",
      }}>
        {/* Sticky header */}
        <div style={{ 
          display:"grid", 
          gridTemplateColumns:gridTemplate,
          background:"#1A1A1A", 
          position:"sticky", 
          top:0, 
          zIndex:10 
        }}>
          {headerCols.map((h,i) => (
            <div key={i} style={{ 
              padding:"12px 16px", 
              fontSize:10, 
              fontWeight:600,
              color:"rgba(255,255,255,0.7)", 
              textTransform:"uppercase", 
              letterSpacing:1,
              fontFamily:"'Inter', sans-serif",
              ...(i===headerCols.length-1 && auditMode
                ? { background:"#2C3E50", color:"#C5A059" } : {})
            }}>
              {h}
            </div>
          ))}
        </div>

        {loading ? (
          <div style={{ padding:16 }}><TableSkeleton/></div>
        ) : (
          <>
            {Object.entries(grouped).map(([cat, items]) => (
              <CategoryGroup
                key={cat}
                category={cat}
                items={items}
                auditMode={auditMode}
                auditData={auditData}
                onPhysicalChange={handlePhysicalChange}
                onRowClick={setSelectedItem}
              />
            ))}
            {filtered.length === 0 && (
              <div style={{ 
                padding:60, 
                textAlign:"center", 
                color:"#7A7A7A", 
                fontSize:13 
              }}>
                No items match your search
              </div>
            )}
          </>
        )}
      </div>

      {/* -- Batch Drill-Down Panel -- */}
      {selectedItem && (
        <BatchPanel item={selectedItem} onClose={() => setSelectedItem(null)}/>
      )}
    </div>
  );
}