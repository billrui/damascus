import { useState, useMemo } from "react";
import { d } from "../data";
import { classifyExpiry } from "../utils";
import { Card, Badge, Btn, Input, Select, SectionHeader, ExpiryBadge } from "../components/UI";

// ─── INVENTORY VIEW ───────────────────────────────────────────────────────────
export function InventoryView({ batches, ingredients: propIngredients }) {
  const INGREDIENTS = propIngredients || [];
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("all");
  const [filterLoc, setFilterLoc] = useState("all");
  const [fefoSort, setFefoSort] = useState(true);

  const categories = ["all", ...new Set(INGREDIENTS.map((i) => i.category))];
  const locations = ["all", ...new Set(batches.map((b) => b.location))];

  const data = useMemo(() => {
    const mapped = INGREDIENTS
      .filter((ing) => {
        const matchSearch = ing.name.toLowerCase().includes(search.toLowerCase());
        const matchCat = filterCat === "all" || ing.category === filterCat;
        return matchSearch && matchCat;
      })
      .map((ing) => {
        const ingBatches = batches.filter((b) => b.ingredientId === ing.id && (filterLoc === "all" || b.location === filterLoc));
        const activeBatches = ingBatches.filter((b) => b.status === "active");
        const totalActive = activeBatches.reduce((s, b) => s + b.remaining, 0);
        const sortedActive = [...activeBatches].sort((a, b) => new Date(a.expiry) - new Date(b.expiry));
        const earliestExp = sortedActive[0];
        const isLow = totalActive <= ing.reorderLevel;
        const value = totalActive * ing.costPerUnit;
        const expiryMs = earliestExp ? new Date(earliestExp.expiry).getTime() : Infinity;
        return { ...ing, ingBatches, activeBatches: sortedActive, totalActive, earliestExp, isLow, value, expiryMs };
      })
      .filter((ing) => ing.ingBatches.length > 0 || filterLoc === "all");

    if (fefoSort) {
      mapped.sort((a, b) => {
        const statusOrder = (item) => {
          if (!item.earliestExp) return 99;
          const days = Math.round((new Date(item.earliestExp.expiry) - new Date()) / 86400000);
          if (days < 0) return 0;
          if (days === 0) return 1;
          if (days <= 3) return 2;
          if (days <= 7) return 3;
          return 4;
        };
        const sa = statusOrder(a), sb = statusOrder(b);
        if (sa !== sb) return sa - sb;
        return a.expiryMs - b.expiryMs;
      });
    }
    return mapped;
  }, [INGREDIENTS, batches, search, filterCat, filterLoc, fefoSort]);

  const summaryCards = [
    { label: "Total Items", value: INGREDIENTS.length, icon: "§", bg: "#EFF6FF" },
    { label: "Low Stock", value: data.filter((d) => d.isLow).length, icon: "!", bg: "#FFFBEB", alert: true },
    { label: "Active Batches", value: batches.filter((b) => b.status === "active").length, icon: "#", bg: "#ECFDF5" },
    { label: "Expired Batches", value: batches.filter((b) => b.status === "expired").length, icon: "×", bg: "#FEF2F2", alert: true },
  ];

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: 28, background: "#F5F2EB" }}>
      <SectionHeader title="Ingredients & Batches" sub={fefoSort ? "FEFO active — expiring items prioritized for consumption" : "Raw material stock with batch tracking"} />

      <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
        <div style={{ flex: 1, minWidth: 180, display: "flex", alignItems: "center", gap: 8, background: "#FFFFFF", borderRadius: 4, padding: "0 14px", border: "1px solid #E5E0D5" }}>
          <span style={{ fontSize: 12, color: "#7A7A7A" }}>🔍</span>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search ingredients..." style={{ border: "none", outline: "none", fontSize: 12, flex: 1, padding: "10px 0", background: "transparent", fontFamily: "'Inter', sans-serif" }} />
        </div>
        <select value={filterCat} onChange={(e) => setFilterCat(e.target.value)} style={{ padding: "0 16px", borderRadius: 4, border: "1px solid #E5E0D5", background: "#FFFFFF", fontSize: 12, color: "#4A4A4A", cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
          {categories.map((c) => <option key={c} value={c}>{c === "all" ? "All Categories" : c}</option>)}
        </select>
        <select value={filterLoc} onChange={(e) => setFilterLoc(e.target.value)} style={{ padding: "0 16px", borderRadius: 4, border: "1px solid #E5E0D5", background: "#FFFFFF", fontSize: 12, color: "#4A4A4A", cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
          {locations.map((l) => <option key={l} value={l}>{l === "all" ? "All Locations" : l}</option>)}
        </select>
        <button onClick={() => setFefoSort(f => !f)} style={{ display: "flex", alignItems: "center", gap: 8, padding: "0 18px", borderRadius: 4, fontSize: 11, fontWeight: 600, cursor: "pointer", border: fefoSort ? "1px solid #C5A059" : "1px solid #E5E0D5", background: fefoSort ? "#FEF9F0" : "#FFFFFF", color: fefoSort ? "#C5A059" : "#7A7A7A", fontFamily: "'Inter', sans-serif" }}>
          <span>⏱</span> FEFO {fefoSort ? "ON" : "OFF"}
        </button>
      </div>

      {fefoSort && data.some(d => d.earliestExp && Math.round((new Date(d.earliestExp.expiry) - new Date()) / 86400000) <= 3) && (
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, background: "#FEF9F0", border: "1px solid #FDE68A", borderRadius: 6, padding: "12px 18px" }}>
          <span style={{ fontSize: 16, color: "#C5A059" }}>⏱</span>
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#B8860B", letterSpacing: "0.3px" }}>FEFO Alert — Priority Items</div>
            <div style={{ fontSize: 10, color: "#92400E", marginTop: 2 }}>Items expiring within 3 days are prioritized. POS will deduct these batches first.</div>
          </div>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 24 }}>
        {summaryCards.map((c) => (
          <Card key={c.label} style={{ padding: 16, display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 6, background: c.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, color: c.alert && c.value > 0 ? "#8B3A3A" : "#C5A059" }}>{c.icon}</div>
            <div>
              <div style={{ fontSize: 9, fontWeight: 600, color: "#7A7A7A", letterSpacing: 0.5, textTransform: "uppercase" }}>{c.label}</div>
              <div style={{ fontSize: 20, fontWeight: 700, color: c.alert && c.value > 0 ? "#8B3A3A" : "#1A1A1A" }}>{c.value}</div>
            </div>
          </Card>
        ))}
      </div>

      <Card style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#F8F8F8" }}>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>#</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Ingredient</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Category</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Unit</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Total Stock</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Batches</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Earliest Expiry</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Value (KES)</th>
                <th style={{ padding: "12px 16px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {data.map((ing, i) => {
                const daysToExp = ing.earliestExp ? Math.round((new Date(ing.earliestExp.expiry) - new Date()) / 86400000) : null;
                const rowBg = daysToExp !== null && daysToExp < 0 ? "#FEF2F2" : daysToExp !== null && daysToExp === 0 ? "#FEF9F0" : daysToExp !== null && daysToExp <= 3 ? "#FFFBEB" : ing.isLow ? "#FFFBEB" : "#FFFFFF";
                const rowBorderLeft = daysToExp !== null && daysToExp < 0 ? "3px solid #8B3A3A" : daysToExp !== null && daysToExp <= 3 ? "3px solid #C5A059" : "3px solid transparent";
                return (
                  <tr key={ing.id} style={{ borderBottom: i < data.length - 1 ? "1px solid #F0EDE6" : "none", background: rowBg, borderLeft: rowBorderLeft }}>
                    <td style={{ padding: "12px 16px", fontSize: 11, color: "#7A7A7A", fontWeight: 600 }}>
                      {fefoSort ? (
                        <span style={{ display: "inline-block", width: 22, height: 22, borderRadius: "50%", textAlign: "center", lineHeight: "22px", fontSize: 10, fontWeight: 700, background: daysToExp !== null && daysToExp < 0 ? "#8B3A3A" : daysToExp !== null && daysToExp <= 3 ? "#C5A059" : "#F0EDE6", color: daysToExp !== null && daysToExp <= 3 ? "#FFFFFF" : "#7A7A7A" }}>{i + 1}</span>
                      ) : i + 1}
                    </td>
                    <td style={{ padding: "12px 16px", fontWeight: 500, fontSize: 12, color: "#1A1A1A" }}>{ing.name}</td>
                    <td style={{ padding: "12px 16px", fontSize: 11, color: "#7A7A7A", textTransform: "capitalize" }}>{ing.category}</td>
                    <td style={{ padding: "12px 16px", fontSize: 11, color: "#7A7A7A" }}>{ing.unit}</td>
                    <td style={{ padding: "12px 16px", fontWeight: 600, fontSize: 12, color: ing.isLow ? "#B8860B" : "#1A1A1A" }}>
                      {ing.totalActive.toLocaleString()}
                      {ing.isLow && <span style={{ marginLeft: 8, fontSize: 9, color: "#B8860B", fontWeight: 600 }}>Reorder</span>}
                    </td>
                    <td style={{ padding: "12px 16px", fontSize: 11, color: "#7A7A7A" }}>{ing.activeBatches.length} batch{ing.activeBatches.length !== 1 ? "es" : ""}</td>
                    <td style={{ padding: "12px 16px" }}>
                      {ing.earliestExp ? (
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <ExpiryBadge batch={ing.earliestExp} />
                          {fefoSort && daysToExp !== null && daysToExp <= 3 && <span style={{ fontSize: 9, fontWeight: 600, color: "#8B3A3A", background: "#FEF2F2", borderRadius: 4, padding: "2px 8px" }}>Priority</span>}
                        </div>
                      ) : <Badge>No Stock</Badge>}
                    </td>
                    <td style={{ padding: "12px 16px", fontWeight: 600, fontSize: 11, color: "#4A4A4A" }}>KES {Math.round(ing.value).toLocaleString()}</td>
                    <td style={{ padding: "12px 16px" }}>
                      {daysToExp !== null && daysToExp < 0 ? <Badge color="#8B3A3A" bg="#FEF2F2">Expired</Badge> : ing.isLow ? <Badge color="#B8860B" bg="#FEF9F0">Reorder</Badge> : <Badge color="#2E7D64" bg="#ECFDF5">Active</Badge>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ─── INVENTORY READ-ONLY VIEW ───────────────────────────────────────────────────
export function InventoryReadOnlyView({ batches }) {
  const [search, setSearch] = useState("");
  const today = new Date();
  const alertItems = propIngredients.map((ing) => {
    const ingBatches = batches.filter((b) => b.ingredientId === ing.id && b.status === "active");
    const totalActive = ingBatches.reduce((s, b) => s + b.remaining, 0);
    const earliestExp = ingBatches.sort((a, b) => new Date(a.expiry) - new Date(b.expiry))[0];
    const daysToExpiry = earliestExp ? Math.ceil((new Date(earliestExp.expiry) - today) / 86400000) : null;
    const isLow = totalActive <= ing.reorderLevel;
    const isExpiring = daysToExpiry !== null && daysToExpiry <= 5;
    if (!isLow && !isExpiring) return null;
    return { ...ing, totalActive, earliestExp, daysToExpiry, isLow, isExpiring };
  }).filter(Boolean).filter(ing => ing.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: 28, background: "#F5F2EB" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 600, color: "#1A1A1A", letterSpacing: "0.5px" }}>Inventory Alerts</div>
          <div style={{ fontSize: 11, color: "#7A7A7A", marginTop: 2 }}>Read-only view · Low stock & expiring items</div>
        </div>
        <div style={{ background: "#FEF9F0", border: "1px solid #FDE68A", borderRadius: 4, padding: "6px 14px", fontSize: 10, color: "#B8860B", fontWeight: 600, letterSpacing: "0.5px" }}>View Only</div>
      </div>

      <div style={{ background: "#FEF9F0", border: "1px solid #FDE68A", borderRadius: 6, padding: "12px 18px", marginBottom: 20, fontSize: 11, color: "#B8860B" }}>
        Showing <strong>{alertItems.length}</strong> items requiring attention (low stock or expiring within 5 days). Please notify management.
      </div>

      <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search ingredients..." style={{ width: "100%", padding: "10px 14px", borderRadius: 4, border: "1px solid #E5E0D5", fontSize: 12, marginBottom: 16, outline: "none", boxSizing: "border-box", fontFamily: "'Inter', sans-serif" }} />

      {alertItems.length === 0 ? (
        <div style={{ textAlign: "center", padding: 60, color: "#7A7A7A" }}>
          <div style={{ fontSize: 36, marginBottom: 12, color: "#2E7D64" }}>✓</div>
          <div style={{ fontWeight: 600, fontSize: 15, color: "#1A1A1A" }}>All Clear</div>
          <div style={{ fontSize: 12, marginTop: 4 }}>No items critically low or expiring soon.</div>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 14 }}>
          {alertItems.map(ing => (
            <div key={ing.id} style={{ background: "#FFFFFF", borderRadius: 6, padding: 16, border: `1px solid ${ing.isExpiring && ing.daysToExpiry <= 1 ? "#FECACA" : ing.isExpiring ? "#FDE68A" : "#FEF3C7"}`, boxShadow: "0 2px 6px rgba(0,0,0,0.04)" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: "#1A1A1A" }}>{ing.name}</div>
                <span style={{ fontSize: 9, background: "#F8F8F8", color: "#7A7A7A", padding: "2px 10px", borderRadius: 4, fontWeight: 600, textTransform: "uppercase" }}>{ing.category}</span>
              </div>
              {ing.isLow && (
                <div style={{ fontSize: 10, color: "#B8860B", background: "#FEF9F0", padding: "6px 10px", borderRadius: 4, marginBottom: 6, fontWeight: 600 }}>
                  Low Stock: {ing.totalActive.toLocaleString()} {ing.unit} remaining (min: {ing.reorderLevel.toLocaleString()})
                </div>
              )}
              {ing.isExpiring && (
                <div style={{ fontSize: 10, color: ing.daysToExpiry <= 0 ? "#991B1B" : ing.daysToExpiry <= 1 ? "#8B3A3A" : "#B8860B", background: ing.daysToExpiry <= 1 ? "#FEF2F2" : "#FEF9F0", padding: "6px 10px", borderRadius: 4, fontWeight: 600 }}>
                  {ing.daysToExpiry <= 0 ? "Expired" : ing.daysToExpiry === 1 ? "Expires Tomorrow" : `Expires in ${ing.daysToExpiry} days`} · Batch: {ing.earliestExp?.batchNo}
                </div>
              )}
              <div style={{ fontSize: 9, color: "#7A7A7A", marginTop: 8 }}>📍 {ing.earliestExp?.location || "—"}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── RECEIVE STOCK VIEW ───────────────────────────────────────────────────────
export function ReceiveStockView({ batches, setBatches, ingredients: propIngredients = [], suppliers: propSuppliers = [] }) {
  const [form, setForm] = useState({ ingredientId: "I01", batchNo: "", qty: "", expiry: "", supplier: "S1", location: "Main Store", costPerUnit: "" });
  const [saved, setSaved] = useState(false);

  const handleSubmit = () => {
    if (!form.batchNo || !form.qty || !form.expiry) return;
    const newBatch = { id: `B${String(Date.now()).slice(-3)}`, ...form, qty: Number(form.qty), remaining: Number(form.qty), costPerUnit: Number(form.costPerUnit), receivedDate: d(0), status: "active" };
    setBatches((p) => [...p, newBatch]);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setForm({ ingredientId: "I01", batchNo: "", qty: "", expiry: "", supplier: "S1", location: "Main Store", costPerUnit: "" });
  };

  const recent = [...batches].sort((a, b) => new Date(b.receivedDate) - new Date(a.receivedDate)).slice(0, 10);

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: 28, background: "#F5F2EB" }}>
      <SectionHeader title="Receive Stock" sub="Add new inventory batches with expiry tracking" />
      <div style={{ display: "grid", gridTemplateColumns: "400px 1fr", gap: 24 }}>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 13, color: "#1A1A1A", marginBottom: 18, letterSpacing: "0.5px" }}>New Batch Receipt</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Select label="Ingredient" value={form.ingredientId} onChange={(e) => setForm((f) => ({ ...f, ingredientId: e.target.value }))}>
              {propIngredients.map((i) => <option key={i.id} value={i.id}>{i.name} ({i.unit})</option>)}
            </Select>
            <Input label="Batch Number" value={form.batchNo} onChange={(e) => setForm((f) => ({ ...f, batchNo: e.target.value }))} placeholder="e.g., BATCH-2024-054" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Input label={`Quantity (${propIngredients.find((i) => i.id === form.ingredientId)?.unit})`} type="number" value={form.qty} onChange={(e) => setForm((f) => ({ ...f, qty: e.target.value }))} />
              <Input label="Cost Per Unit (KES)" type="number" value={form.costPerUnit} onChange={(e) => setForm((f) => ({ ...f, costPerUnit: e.target.value }))} />
            </div>
            <Input label="Expiry Date" type="date" value={form.expiry} onChange={(e) => setForm((f) => ({ ...f, expiry: e.target.value }))} />
            <Select label="Supplier" value={form.supplier} onChange={(e) => setForm((f) => ({ ...f, supplier: e.target.value }))}>
              {propSuppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Select label="Storage Location" value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}>
              {["Main Store", "Kitchen", "Cold Room", "Dry Store"].map((l) => <option key={l}>{l}</option>)}
            </Select>
            <Btn onClick={handleSubmit} style={{ width: "100%", padding: 12, borderRadius: 4, fontSize: 12 }}>{saved ? "Batch Recorded" : "Receive Batch"}</Btn>
          </div>
        </Card>

        <Card>
          <div style={{ fontWeight: 600, fontSize: 13, color: "#1A1A1A", marginBottom: 18, letterSpacing: "0.5px" }}>Recent Receipts</div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#F8F8F8" }}>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Batch No</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Ingredient</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Qty</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Expiry</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Location</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((b, i) => {
                  const ing = propIngredients.find((x) => x.id === b.ingredientId);
                  return (
                    <tr key={b.id} style={{ borderBottom: i < recent.length - 1 ? "1px solid #F0EDE6" : "none" }}>
                      <td style={{ padding: "10px 14px", fontWeight: 500, fontSize: 11, color: "#C5A059" }}>{b.batchNo}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#4A4A4A" }}>{ing?.name}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#4A4A4A" }}>{b.qty} {ing?.unit}</td>
                      <td style={{ padding: "10px 14px" }}><ExpiryBadge batch={b} /></td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#7A7A7A" }}>{b.location}</td>
                      <td style={{ padding: "10px 14px" }}><Badge color={b.status === "active" ? "#2E7D64" : "#8B3A3A"} bg={b.status === "active" ? "#ECFDF5" : "#FEF2F2"}>{b.status}</Badge></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── ISSUE STOCK VIEW ─────────────────────────────────────────────────────────
export function IssueStockView({ batches, setBatches, storeIssues, setStoreIssues, user, ingredients: propIngredients = [] }) {
  const [form, setForm] = useState({ ingredientId: "I01", to: "Kitchen", qty: "" });
  const [saved, setSaved] = useState(false);

  const availableBatches = (ingId) => batches.filter((b) => b.ingredientId === ingId && b.status === "active" && b.remaining > 0).sort((a, b) => new Date(a.expiry) - new Date(b.expiry));
  const totalAvailable = (ingId) => availableBatches(ingId).reduce((s, b) => s + b.remaining, 0);

  const handleIssue = () => {
    if (!form.qty || Number(form.qty) <= 0) return;
    let needed = Number(form.qty);
    const eligible = availableBatches(form.ingredientId);
    const newBatches = [...batches];

    for (const b of eligible) {
      if (needed <= 0) break;
      const take = Math.min(b.remaining, needed);
      const idx = newBatches.findIndex((nb) => nb.id === b.id);
      newBatches[idx] = { ...newBatches[idx], remaining: newBatches[idx].remaining - take };
      if (newBatches[idx].remaining === 0) newBatches[idx] = { ...newBatches[idx], status: "consumed" };
      needed -= take;
    }

    const newIssue = { id: `SI${String(Date.now()).slice(-4)}`, date: d(0), from: "Main Store", to: form.to, ingredientId: form.ingredientId, batchId: eligible[0]?.id, qty: Number(form.qty), issuedBy: user.name, approvedBy: "Manager" };
    setBatches(newBatches);
    setStoreIssues((p) => [...p, newIssue]);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setForm((f) => ({ ...f, qty: "" }));
  };

  const ing = propIngredients.find((i) => i.id === form.ingredientId);
  const avail = totalAvailable(form.ingredientId);
  const fefoPreview = availableBatches(form.ingredientId).slice(0, 3);

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: 28, background: "#F5F2EB" }}>
      <SectionHeader title="Issue Stock" sub="Issue ingredients from store to kitchen/bar using FEFO" />
      <div style={{ display: "grid", gridTemplateColumns: "380px 1fr", gap: 24 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <Card>
            <div style={{ fontWeight: 600, fontSize: 13, color: "#1A1A1A", marginBottom: 18, letterSpacing: "0.5px" }}>Issue Request</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <Select label="Ingredient" value={form.ingredientId} onChange={(e) => setForm((f) => ({ ...f, ingredientId: e.target.value }))}>
                {propIngredients.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
              </Select>
              <Select label="Issue To" value={form.to} onChange={(e) => setForm((f) => ({ ...f, to: e.target.value }))}>
                {["Kitchen", "Cold Room", "Dry Store"].map((l) => <option key={l}>{l}</option>)}
              </Select>
              <Input label={`Quantity (${ing?.unit}) — Available: ${avail}`} type="number" value={form.qty} onChange={(e) => setForm((f) => ({ ...f, qty: e.target.value }))} placeholder={`Max: ${avail}`} />
              <Btn onClick={handleIssue} style={{ width: "100%", padding: 12, borderRadius: 4, fontSize: 12 }}>{saved ? "Issued" : "Issue Stock (FEFO)"}</Btn>
            </div>
          </Card>

          {fefoPreview.length > 0 && (
            <Card>
              <div style={{ fontWeight: 600, fontSize: 12, color: "#1A1A1A", marginBottom: 14, letterSpacing: "0.5px" }}>FEFO Batch Queue</div>
              <div style={{ fontSize: 10, color: "#7A7A7A", marginBottom: 12 }}>Batches consumed in order (earliest expiry first)</div>
              {fefoPreview.map((b, i) => (
                <div key={b.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: i < fefoPreview.length - 1 ? "1px solid #F0EDE6" : "none" }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 500, color: "#1A1A1A" }}>{b.batchNo}</div>
                    <div style={{ fontSize: 10, color: "#7A7A7A" }}>{b.remaining} {ing?.unit} available</div>
                  </div>
                  <ExpiryBadge batch={b} />
                </div>
              ))}
            </Card>
          )}
        </div>

        <Card>
          <div style={{ fontWeight: 600, fontSize: 13, color: "#1A1A1A", marginBottom: 18, letterSpacing: "0.5px" }}>Recent Issues</div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#F8F8F8" }}>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Ref</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Date</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Ingredient</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Qty</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>From → To</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Issued By</th>
                  <th style={{ padding: "10px 14px", textAlign: "left", fontSize: 10, fontWeight: 600, color: "#7A7A7A", borderBottom: "1px solid #E5E0D5", letterSpacing: "0.5px", textTransform: "uppercase" }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {[...storeIssues].reverse().slice(0, 12).map((si, i) => {
                  const ing = propIngredients.find((x) => x.id === si.ingredientId);
                  return (
                    <tr key={si.id} style={{ borderBottom: i < 11 ? "1px solid #F0EDE6" : "none" }}>
                      <td style={{ padding: "10px 14px", fontWeight: 500, fontSize: 11, color: "#C5A059" }}>{si.id}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#7A7A7A" }}>{si.date}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#4A4A4A", fontWeight: 500 }}>{ing?.name}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#4A4A4A" }}>{si.qty} {ing?.unit}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#7A7A7A" }}>{si.from} → {si.to}</td>
                      <td style={{ padding: "10px 14px", fontSize: 11, color: "#7A7A7A" }}>{si.issuedBy}</td>
                      <td style={{ padding: "10px 14px" }}><Badge color="#2E7D64" bg="#ECFDF5">Issued</Badge></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}